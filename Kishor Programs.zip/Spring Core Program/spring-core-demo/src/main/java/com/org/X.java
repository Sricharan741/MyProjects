package com.org;

import org.springframework.beans.factory.annotation.Autowired;

public class X {
	@Autowired
	private Y y; // it is not initialized
	
	public X() {
		System.out.println("X() constructor");
	}
	
	public void demo() {
		System.out.println("demo() inside X calling display");
		y.display();
	}
}

/*
 *  Y y = new Y();
 *  @Autowired Y y;
 * 
 * X & Y both must be in the spring container
 * 
 */
