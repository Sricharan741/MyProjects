package com.org;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {
	public Config() {
		System.out.println("Config() constructor");
	}
	
	@Bean("x")
	public X createX() {  // <bean id = "x" class = "com.org.X"> or @Component class X
		return new X();
	}
	
	@Bean
	public Y createY() {
		return new Y();
	}
}
