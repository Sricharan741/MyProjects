package com.org;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		X x1 = (X) context.getBean("x");
		x1.demo(); // demo is calling y.display(), but y object is not assigned
	}

}
