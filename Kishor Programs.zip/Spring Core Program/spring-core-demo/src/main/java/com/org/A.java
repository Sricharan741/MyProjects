package com.org;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class A {  
	@Value("Alexandar")
	private String user; // <property name = "user" value = "Alexandar">
	public A() {
		System.out.println("A() constructor");
	}
	public String getUser() {
		return user;
	}
}

/*
 *  A a1 = new A();
 *  <bean id = "a1" class = "com.org.A">
 *  @Component public class A { } 
 *  @Component, @Configuration, @Service, @Controller, @Repository, @RestController 
 *  @Configuration 
 *  public class Config {
 *    
 *     @Bean
 *     public A m1() { 
 *        return new A();
 *     }
 *  }
 */
