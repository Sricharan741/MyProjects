package com.org;

import org.springframework.stereotype.Component;

//@Component
public class B {
	public B() {
		System.out.println("B() constructor");
	}
}
