package com.org;

public class Y {
	public Y() {
		System.out.println("Y() constructor");
	}
	
	public void display() {
		System.out.println("display() inside y");
	}
}
