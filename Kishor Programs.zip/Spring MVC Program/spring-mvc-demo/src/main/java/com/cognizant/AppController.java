package com.cognizant;

import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AppController {

	// you can create methods with either String or ModelAndView return types
	
	@RequestMapping(value = "/test", method = RequestMethod.GET)
	public ModelAndView hello() {
		// 1st parameter is view name, 2nd is model name & 3rd is the model
		ModelAndView mav = new ModelAndView("welcome", "xyz", LocalDate.now());
		return mav;
	}
	
	@RequestMapping(value = "loginPage")
	public ModelAndView login() {
		return new ModelAndView("login", "demo", "some other data");
	}
}
