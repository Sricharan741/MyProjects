package com.org.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.org.beans.Employee;
import com.org.utility.DBUtility;

// this will have CRUD operations
public class EmployeeDAO {
	// store method takes employee object which is initialized by the client
	// client will pass only name & dob, whereas id will be auto-incremented
	public int store(Employee employee) {
		try {
			Connection connection = DBUtility.getConnection();
			String insertQuery = "insert into employee (emp_name, dob) values(?, ?)";
			PreparedStatement statement = connection.prepareStatement(insertQuery);
			statement.setString(1, employee.getName());
			statement.setDate(2, Date.valueOf(employee.getDob())); // LocalDate to Date type, yyyy-MM-dd
			int count = statement.executeUpdate();
			statement.close();
			connection.close();
			return count;
		} catch(Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	public List<Employee> retrieveAll() {
		List<Employee> list = new ArrayList<Employee>();
		try {
			Connection connection = DBUtility.getConnection();
			String selectQuery = "select * from employee";
			PreparedStatement statement = connection.prepareStatement(selectQuery);
			ResultSet resultSet = statement.executeQuery(); // result set will be created with records
			while(resultSet.next()) {
				Employee employee = new Employee();
				employee.setId(resultSet.getInt("emp_id")); // takes the value of emp_id and initializes id of employee
				employee.setName(resultSet.getString("emp_name")); // takes the value of emp_name & initializes name of employee
				employee.setDob(resultSet.getDate("dob").toLocalDate());
				list.add(employee);
			}
			resultSet.close();
			statement.close();
			connection.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
}
