package com.org.utility;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtility {
	public static Connection getConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/cts_jan21";
			String username = "root";
			String password = "root";
			Connection connection = DriverManager.getConnection(url, username, password);
			return connection;
		} catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
