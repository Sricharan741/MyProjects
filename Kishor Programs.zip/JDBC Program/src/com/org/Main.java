package com.org;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.org.beans.Employee;
import com.org.dao.EmployeeDAO;

/*
 * applying single ton pattern on the DAO class
 * applying exception-handling in correct way i.e., finally block, caching specific exceptions, throws clause
 * using service layer in-between client & the DAO layer to apply abstraction over the DAO & business logics
 * using interface in the client instead of class DAO
 * using factory pattern to create DAO instance 
 */

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int options = 0;
		EmployeeDAO dao = new EmployeeDAO();
		do {
			System.out.println("1: Store 2: Retrieve All -1: Exit");
			options = scanner.nextInt();
			switch(options) {
				case 1: 
					System.out.println("Enter name & DOB (YYYY-MM-dd)");
					Employee employee = new Employee();
					employee.setName(scanner.next());
					employee.setDob(LocalDate.parse(scanner.next())); // you pass yyyy-MM-dd
					int status = dao.store(employee); // returns 0 or 1
					if(status > 0) 
						System.out.println("Stored successfully");
					else 
						System.out.println("Sorry data is not stored");
					break;
				case 2:
					List<Employee> employees = dao.retrieveAll();
					employees.stream().forEach(item -> System.out.println(item));
					break;
			}
		} while(options != -1);
		System.out.println("***** Thank you ******");
		scanner.close();
	}

}
