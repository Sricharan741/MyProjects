package com.cognizant.mfpe.risk.pojos;

import java.time.LocalDate;

import com.cognizant.mfpe.risk.pojo.Collateral;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class CollateralLoan {

	private Integer loanId;
	private Integer collateralId;
	private Double collateralValue;
	private LocalDate pledgedDate;
	private Collateral collateral;

}
