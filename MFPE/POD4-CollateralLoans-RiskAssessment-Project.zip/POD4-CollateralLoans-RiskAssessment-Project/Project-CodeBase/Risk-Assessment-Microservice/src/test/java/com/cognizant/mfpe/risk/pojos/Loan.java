package com.cognizant.mfpe.risk.pojos;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Loan {

	private Integer loanProductId;
	private String loanProductName;
	private Double maxLoanEligible;
	private Double interestRate;
	private Integer tenure;
	private String collateralType;

}
