package com.cognizant.mfpe.risk.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.cognizant.mfpe.risk.entities.CollateralMarketValue;
import com.cognizant.mfpe.risk.entities.CollateralRisk;
import com.cognizant.mfpe.risk.exception.CollateralLoanNotFoundException;
import com.cognizant.mfpe.risk.exception.CollateralMarketValueDataNotFoundException;
import com.cognizant.mfpe.risk.exception.CollateralNotAssignedException;
import com.cognizant.mfpe.risk.exception.RiskCalculatorNotAvailableException;
import com.cognizant.mfpe.risk.feign.CollateralFeignClient;
import com.cognizant.mfpe.risk.feign.LoanFeignClient;
import com.cognizant.mfpe.risk.pojo.Collateral;
import com.cognizant.mfpe.risk.pojo.CollateralCashDeposit;
import com.cognizant.mfpe.risk.pojo.CollateralDetailsResponseModel;
import com.cognizant.mfpe.risk.pojo.CollateralRealEstate;
import com.cognizant.mfpe.risk.pojo.CollateralType;
import com.cognizant.mfpe.risk.pojo.LoanDetailsResponseModel;
import com.cognizant.mfpe.risk.pojos.CollateralLoan;
import com.cognizant.mfpe.risk.pojos.Customer;
import com.cognizant.mfpe.risk.pojos.CustomerLoan;
import com.cognizant.mfpe.risk.pojos.Loan;
import com.cognizant.mfpe.risk.repository.CollateralMarketValueRepository;
import com.cognizant.mfpe.risk.repository.CollateralRiskRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * Test - LoanService Test class
 */
@SpringBootTest
@RunWith(SpringRunner.class)
@Slf4j
class RiskServiceTest {

	@MockBean
	private CollateralRiskRepository collateralRiskRepository;

	@MockBean
	private CollateralMarketValueRepository collateralMarketValueRepository;

	@MockBean
	private CollateralFeignClient collateralFeignClient;

	@MockBean
	private LoanFeignClient loanFeignClient;

	@InjectMocks
	@Autowired
	private RiskManagementServiceImpl service;

	private static CollateralRealEstate realEstate;
	private static CollateralCashDeposit cashDeposit;
	private static Customer customer1;
	private static Customer customer2;
	private static Loan loanProduct1;
	private static Loan loanProduct2;
	private static CustomerLoan custLoan1;
	private static CustomerLoan custLoan2;
	private static CollateralRisk collateralRiskRealEstate;
	private static CollateralRisk collateralRiskCashDeposit;
	private static CollateralMarketValue collateralMarketValue1;
	private static CollateralMarketValue collateralMarketValue2;
	private static LoanDetailsResponseModel loanDetailsResponseModel1;
	private static LoanDetailsResponseModel loanDetailsResponseModel2;
	private static CollateralDetailsResponseModel collateralDetailsResponseModel1;
	private static CollateralDetailsResponseModel collateralDetailsResponseModel2;
	private static CollateralLoan collateralLoanRealEstate;
	private static CollateralLoan collateralLoanCashDeposit;

	@BeforeAll
	static void init() {
		log.info("Initializing data...");
		ModelMapper modelMapper = new ModelMapper();
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);

		realEstate = new CollateralRealEstate();
		realEstate.setCollateralId(123);
		realEstate.setCollateralType(CollateralType.REAL_ESTATE.name());
		realEstate.setCurrentValue(1500000.0);
		realEstate.setDepreciationRate(5.0);
		realEstate.setLoanId(10001);
		realEstate.setAddress("Kolkata");
		realEstate.setOwnerName("Himashu");
		realEstate.setRatePerSqFt(5000.0);

		cashDeposit = new CollateralCashDeposit();
		cashDeposit.setCollateralId(456);
		cashDeposit.setCollateralType(CollateralType.CASH_DEPOSIT.name());
		cashDeposit.setCurrentValue(2000000.0);
		cashDeposit.setDepositAmount(800000.0);
		cashDeposit.setInterestRate(15.0);
		cashDeposit.setLoanId(10002);
		cashDeposit.setLockPeriod(10);
		cashDeposit.setAddress("Kolkata");
		cashDeposit.setOwnerName("Himashu");

		customer1 = new Customer();
		customer1.setCustomerId(101);
		customer1.setName("Sampath");
		customer1.setEmailId("sampath123@gmail.com");
		customer1.setMobileNo("7780184807");
		customer1.setAddress("Vijayawada");

		customer2 = new Customer();
		customer2.setCustomerId(102);
		customer2.setName("Sricharan");
		customer2.setEmailId("sricharan123@gmail.com");
		customer2.setMobileNo("9874561231");
		customer2.setAddress("Kolkata");

		loanProduct1 = new Loan();
		loanProduct1.setLoanProductId(1001);
		loanProduct1.setLoanProductName("Home Loan");
		loanProduct1.setMaxLoanEligible(3000000.00);
		loanProduct1.setInterestRate(10.5);
		loanProduct1.setTenure(48);
		loanProduct1.setCollateralType("REAL_ESTATE");

		loanProduct2 = new Loan();
		loanProduct2.setLoanProductId(1002);
		loanProduct2.setLoanProductName("Home Loan");
		loanProduct2.setMaxLoanEligible(1100000.00);
		loanProduct2.setInterestRate(9.5);
		loanProduct2.setTenure(40);
		loanProduct2.setCollateralType("CASH_DEPOSIT");

		custLoan1 = new CustomerLoan();
		custLoan1.setLoanId(10001);
		custLoan1.setLoanProductId(1001);
		custLoan1.setCustomerId(101);
		custLoan1.setLoanPrincipal(2500000.0);
		custLoan1.setTenure(48);
		custLoan1.setInterest(10.5);
		custLoan1.setEmi(64008.0);
		custLoan1.setCollateralId(null);
		custLoan1.setLoan(loanProduct1);
		custLoan1.setCustomer(customer1);

		custLoan2 = new CustomerLoan();
		custLoan2.setLoanId(10002);
		custLoan2.setLoanProductId(1002);
		custLoan2.setCustomerId(102);
		custLoan2.setLoanPrincipal(900000.0);
		custLoan2.setTenure(40);
		custLoan2.setInterest(9.5);
		custLoan2.setEmi(26338.0);
		custLoan2.setCollateralId(null);
		custLoan2.setLoan(loanProduct2);
		custLoan2.setCustomer(customer2);

		collateralMarketValue1 = CollateralMarketValue.builder().loanId(10001).customerId(101)
				.collateralType(CollateralType.REAL_ESTATE.name()).marketValue(1000.0).build();

		collateralMarketValue2 = CollateralMarketValue.builder().loanId(10002).customerId(102)
				.collateralType(CollateralType.CASH_DEPOSIT.name()).marketValue(10.2).build();

		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		loanDetailsResponseModel1 = modelMapper.map(custLoan1, LoanDetailsResponseModel.class);
		loanDetailsResponseModel1.setSanctionedLoanAmount(custLoan1.getLoanPrincipal());
		loanDetailsResponseModel1.setCollateralType(custLoan1.getLoan().getCollateralType());
		loanDetailsResponseModel1.setCollateralId(123);

		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		loanDetailsResponseModel2 = modelMapper.map(custLoan2, LoanDetailsResponseModel.class);
		loanDetailsResponseModel2.setSanctionedLoanAmount(custLoan2.getLoanPrincipal());
		loanDetailsResponseModel2.setCollateralType(custLoan2.getLoan().getCollateralType());
		loanDetailsResponseModel2.setCollateralId(456);

		collateralLoanRealEstate = new CollateralLoan();
		collateralLoanRealEstate.setCollateralId(123);
		collateralLoanRealEstate.setLoanId(10001);
		collateralLoanRealEstate.setCollateralValue(1500000.0);
		collateralLoanRealEstate.setCollateral(modelMapper.map(realEstate, Collateral.class));
		collateralLoanRealEstate.setPledgedDate(LocalDate.now());

		collateralLoanCashDeposit = new CollateralLoan();
		collateralLoanCashDeposit.setCollateralId(456);
		collateralLoanCashDeposit.setLoanId(10002);
		collateralLoanCashDeposit.setCollateralValue(20000000.0);
		collateralLoanCashDeposit.setCollateral(modelMapper.map(cashDeposit, Collateral.class));
		collateralLoanCashDeposit.setPledgedDate(LocalDate.now());

		Map<String, Object> details1 = new LinkedHashMap<>();
		details1.put("loanId", collateralLoanRealEstate.getLoanId());
		details1.put("collateralType", collateralLoanRealEstate.getCollateral().getCollateralType());
		details1.put("details", collateralLoanRealEstate.getCollateral());
		collateralDetailsResponseModel1 = new CollateralDetailsResponseModel(details1);

		Map<String, Object> details2 = new LinkedHashMap<>();
		details2.put("loanId", collateralLoanCashDeposit.getLoanId());
		details2.put("collateralType", collateralLoanCashDeposit.getCollateral().getCollateralType());
		details2.put("details", collateralLoanCashDeposit.getCollateral());
		collateralDetailsResponseModel2 = new CollateralDetailsResponseModel(details2);

		collateralRiskRealEstate = new CollateralRisk();
		collateralRiskRealEstate.setLoanId(10001);
		collateralRiskRealEstate.setDateAssessed(LocalDate.now().toString());
		collateralRiskRealEstate.setMarketValue(299250.0);
		collateralRiskRealEstate.setSanctionedLoan(2500000.0);
		collateralRiskRealEstate.setRiskPercent(BigDecimal.valueOf(88.03));

		collateralRiskCashDeposit = new CollateralRisk();
		collateralRiskCashDeposit.setLoanId(10002);
		collateralRiskCashDeposit.setDateAssessed(LocalDate.now().toString());
		collateralRiskCashDeposit.setMarketValue(868544.0);
		collateralRiskCashDeposit.setSanctionedLoan(900000.0);
		collateralRiskCashDeposit.setRiskPercent(BigDecimal.valueOf(3.50));
	}

	@Test
	void testGetCollateralMarketValues() throws Exception {
		log.info("testGetCollateralMarketValues");
		collateralMarketValueRepository.save(collateralMarketValue1);
		collateralMarketValueRepository.save(collateralMarketValue2);
		List<CollateralMarketValue> list = new ArrayList<>();
		list.add(collateralMarketValue1);
		list.add(collateralMarketValue2);
		when(service.getCollateralMarketValues()).thenReturn(list);
		when(collateralMarketValueRepository.findAll()).thenReturn(list);
		assertThat(service.getCollateralMarketValues().size()).isEqualTo(list.size());
	}

	@Test
	void testGetRealEstateCollateralRiskWithValidLoanId() throws Exception {
		log.info("testGetRealEstateCollateralRiskWithValidLoanId");
		collateralMarketValueRepository.save(collateralMarketValue1);
		when(collateralMarketValueRepository.findByLoanId(10001)).thenReturn(collateralMarketValue1);
		when(loanFeignClient.getLoanDetails(10001, 101, "token"))
				.thenReturn(ResponseEntity.ok(loanDetailsResponseModel1));
		when(collateralFeignClient.getCollaterals(10001, 123, "token"))
				.thenReturn(ResponseEntity.ok(collateralDetailsResponseModel1));
		collateralRiskRepository.save(collateralRiskRealEstate);
		when(collateralRiskRepository.save(any(CollateralRisk.class))).thenReturn(collateralRiskRealEstate);
		assertThat(service.getCollateralRisk(10001, "token")).isEqualTo(collateralRiskRealEstate);
	}

	@Test
	void testGetCashDepositCollateralRiskWithValidLoanId() throws Exception {
		log.info("testGetCashDepositCollateralRiskWithValidLoanId");
		collateralMarketValueRepository.save(collateralMarketValue2);
		when(collateralMarketValueRepository.findByLoanId(10002)).thenReturn(collateralMarketValue2);
		when(loanFeignClient.getLoanDetails(10002, 102, "token"))
				.thenReturn(ResponseEntity.ok(loanDetailsResponseModel2));
		when(collateralFeignClient.getCollaterals(10002, 456, "token"))
				.thenReturn(ResponseEntity.ok(collateralDetailsResponseModel2));
		collateralRiskRepository.save(collateralRiskCashDeposit);
		when(collateralRiskRepository.save(any(CollateralRisk.class))).thenReturn(collateralRiskCashDeposit);
		assertThat(service.getCollateralRisk(10002, "token")).isEqualTo(collateralRiskCashDeposit);
	}

	@Test
	void testGetRealEstateCollateralRiskWithValidLoanIdButNoMarketValueData() throws Exception {
		log.info("testGetRealEstateCollateralRiskWithValidLoanId");
		collateralMarketValueRepository.save(collateralMarketValue1);
		when(collateralMarketValueRepository.findByLoanId(10001)).thenReturn(null);
		when(loanFeignClient.getLoanDetails(10001, 101, "token"))
				.thenReturn(ResponseEntity.ok(loanDetailsResponseModel1));
		when(collateralFeignClient.getCollaterals(10001, 123, "token"))
				.thenReturn(ResponseEntity.ok(collateralDetailsResponseModel1));
		collateralRiskRepository.save(collateralRiskRealEstate);
		when(collateralRiskRepository.save(any(CollateralRisk.class))).thenReturn(collateralRiskRealEstate);
		assertThrows(CollateralMarketValueDataNotFoundException.class, () -> service.getCollateralRisk(10001, "token"));
	}

	@Test
	void testGetRealEstateCollateralRiskWithValidLoanIdButCollateralNotAssignedException() throws Exception {
		log.info("testGetRealEstateCollateralRiskWithValidLoanId");
		collateralMarketValueRepository.save(collateralMarketValue1);
		loanDetailsResponseModel1.setCollateralId(null);
		when(collateralMarketValueRepository.findByLoanId(10001)).thenReturn(collateralMarketValue1);
		when(loanFeignClient.getLoanDetails(10001, 101, "token"))
				.thenReturn(ResponseEntity.ok(loanDetailsResponseModel1));
		when(collateralFeignClient.getCollaterals(10001, 123, "token"))
				.thenReturn(ResponseEntity.ok(collateralDetailsResponseModel1));
		collateralRiskRepository.save(collateralRiskRealEstate);
		when(collateralRiskRepository.save(any(CollateralRisk.class))).thenReturn(collateralRiskRealEstate);
		assertThrows(CollateralNotAssignedException.class, () -> service.getCollateralRisk(10001, "token"));
		loanDetailsResponseModel1.setCollateralId(123);
	}

	@Test
	void testGetRealEstateCollateralRiskWithValidLoanIdButNoCollateralDetailsData() throws Exception {
		log.info("testGetRealEstateCollateralRiskWithValidLoanId");
		collateralMarketValueRepository.save(collateralMarketValue1);
		when(collateralMarketValueRepository.findByLoanId(10001)).thenReturn(collateralMarketValue1);
		when(loanFeignClient.getLoanDetails(10001, 101, "token"))
				.thenReturn(ResponseEntity.ok(loanDetailsResponseModel1));
		when(collateralFeignClient.getCollaterals(10001, 123, "token")).thenReturn(ResponseEntity.ok(null));
		collateralRiskRepository.save(collateralRiskRealEstate);
		when(collateralRiskRepository.save(any(CollateralRisk.class))).thenReturn(collateralRiskRealEstate);
		assertThrows(CollateralLoanNotFoundException.class, () -> service.getCollateralRisk(10001, "token"));
	}

	@Test
	void testGetRealEstateCollateralRiskWithValidLoanIdButCollateralTypeMismatchException() throws Exception {
		log.info("testGetRealEstateCollateralRiskWithValidLoanId");
		collateralMarketValueRepository.save(collateralMarketValue1);
		when(collateralMarketValueRepository.findByLoanId(10001)).thenReturn(collateralMarketValue1);
		when(loanFeignClient.getLoanDetails(10001, 101, "token"))
				.thenReturn(ResponseEntity.ok(loanDetailsResponseModel1));
		collateralDetailsResponseModel1.getCollateralDetails().put("collateralType",
				CollateralType.CASH_DEPOSIT.name());
		when(collateralFeignClient.getCollaterals(10001, 123, "token"))
				.thenReturn(ResponseEntity.ok(collateralDetailsResponseModel1));
		collateralRiskRepository.save(collateralRiskRealEstate);
		when(collateralRiskRepository.save(any(CollateralRisk.class))).thenReturn(collateralRiskRealEstate);
		assertThrows(RiskCalculatorNotAvailableException.class, () -> service.getCollateralRisk(10001, "token"));
		collateralDetailsResponseModel1.getCollateralDetails().put("collateralType", CollateralType.REAL_ESTATE.name());
	}

}
