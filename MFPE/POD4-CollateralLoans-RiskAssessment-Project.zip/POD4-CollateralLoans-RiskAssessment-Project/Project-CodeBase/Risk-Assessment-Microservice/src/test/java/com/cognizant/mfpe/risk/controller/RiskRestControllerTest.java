package com.cognizant.mfpe.risk.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.cognizant.mfpe.risk.entities.CollateralMarketValue;
import com.cognizant.mfpe.risk.entities.CollateralRisk;
import com.cognizant.mfpe.risk.exception.CollateralMarketValueDataNotFoundException;
import com.cognizant.mfpe.risk.exception.RiskCalculatorNotAvailableException;
import com.cognizant.mfpe.risk.feign.AuthorizationClient;
import com.cognizant.mfpe.risk.pojo.CollateralType;
import com.cognizant.mfpe.risk.repository.CollateralMarketValueRepository;
import com.cognizant.mfpe.risk.service.RiskManagementService;

import lombok.extern.slf4j.Slf4j;

@RunWith(SpringRunner.class)
@WebMvcTest(RiskRestController.class)
@Slf4j
class RiskRestControllerTests {

	@Autowired
	private MockMvc mvc;

	@MockBean
	private RiskManagementService service;

	@MockBean
	private AuthorizationClient authclient;

	@MockBean
	private CollateralMarketValueRepository collateralMarketValueRepository;

	private static CollateralRisk collateralRisk;
	private static CollateralMarketValue collateralMarketValue1;
	private static CollateralMarketValue collateralMarketValue2;

	@BeforeAll
	static void init() {

		collateralMarketValue1 = CollateralMarketValue.builder().loanId(10001).customerId(101)
				.collateralType(CollateralType.REAL_ESTATE.name()).marketValue(1000.0).build();

		collateralMarketValue2 = CollateralMarketValue.builder().loanId(10002).customerId(102)
				.collateralType(CollateralType.CASH_DEPOSIT.name()).marketValue(10.2).build();

		collateralRisk = new CollateralRisk();
		collateralRisk.setLoanId(10001);
		collateralRisk.setDateAssessed(LocalDate.now().toString());
		collateralRisk.setMarketValue(2300000.0);
		collateralRisk.setSanctionedLoan(2500000.0);
		collateralRisk.setRiskId(1);
		collateralRisk.setRiskPercent(BigDecimal.valueOf(8));
	}

	@Test
	void testGetCollateralRiskWithValidLoanId() throws Exception {
		log.info("testGetLoanDetailsUsingLoanIdAndCustomerId");
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		when(service.getCollateralRisk(10001, "token")).thenReturn(collateralRisk);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getCollateralRisk?loanId=10001")
				.header("Authorization", "token").accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testGetCollateralRiskWithValidLoanIdWithMissingHeaderException() throws Exception {
		log.info("testGetLoanDetailsUsingLoanIdAndCustomerId");
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		when(service.getCollateralRisk(10001, "token")).thenReturn(collateralRisk);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getCollateralRisk?loanId=10001")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(400, status);
	}

	@Test
	void testGetCollateralRiskWithValidLoanIdButUnauthorized() throws Exception {
		log.info("testGetCollateralRiskWithValidLoanIdButUnauthorized");
		when(authclient.authorizeTheRequest("token")).thenReturn(false);
		when(service.getCollateralRisk(10001, "token")).thenReturn(collateralRisk);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getCollateralRisk?loanId=10001")
				.header("Authorization", "token").accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(401, status);
	}

	@Test
	void testGetCollateralRiskWithValidLoanIdButCollateralMarketValueNotExists() throws Exception {
		log.info("testGetCollateralRiskWithValidLoanIdButUnauthorized");
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		when(service.getCollateralRisk(10001, "token")).thenThrow(CollateralMarketValueDataNotFoundException.class);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getCollateralRisk?loanId=10001")
				.header("Authorization", "token").accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(404, status);
	}

	@Test
	void testGetCollateralRiskWithValidLoanIdButRiskCalculatorNotExistsForGivenCollateralType() throws Exception {
		log.info("testGetCollateralRiskWithValidLoanIdButUnauthorized");
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		when(service.getCollateralRisk(10001, "token")).thenThrow(RiskCalculatorNotAvailableException.class);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getCollateralRisk?loanId=10001")
				.header("Authorization", "token").accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(501, status);
	}

	@Test
	void testGetCollateralMarketValues() throws Exception {
		log.info("testGetCollateralMarketValues");
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		List<CollateralMarketValue> list = new ArrayList<>();
		list.add(collateralMarketValue1);
		list.add(collateralMarketValue2);
		when(service.getCollateralMarketValues()).thenReturn(list);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getCollateralMarketValues")
				.header("Authorization", "token").contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);

		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testGetCollateralMarketValuesButUnauthorized() throws Exception {
		log.info("testGetCollateralMarketValuesButUnauthorized");
		when(authclient.authorizeTheRequest("token")).thenReturn(false);
		List<CollateralMarketValue> list = new ArrayList<>();
		list.add(collateralMarketValue1);
		list.add(collateralMarketValue2);
		when(service.getCollateralMarketValues()).thenReturn(list);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getCollateralMarketValues")
				.header("Authorization", "token").contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);

		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(401, status);
	}

	@Test
	void testHealthCheck() throws Exception {
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/health-check").header("Authorization", "token")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mvc.perform(requestBuilder).andReturn();
		assertEquals(200, result.getResponse().getStatus());
	}

	@Test
	void testHealthCheckFailure() throws Exception {
		when(authclient.authorizeTheRequest("token")).thenReturn(false);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/health-check").header("Authorization", "token")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mvc.perform(requestBuilder).andReturn();
		assertEquals(401, result.getResponse().getStatus());
	}
}