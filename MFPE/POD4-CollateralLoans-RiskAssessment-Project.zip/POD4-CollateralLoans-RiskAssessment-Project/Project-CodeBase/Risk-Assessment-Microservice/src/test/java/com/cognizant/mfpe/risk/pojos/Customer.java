package com.cognizant.mfpe.risk.pojos;

import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@SuppressWarnings("unused")
@NoArgsConstructor
public class Customer {

	private Integer customerId;
	private String name;
	private String emailId;
	private String mobileNo;
	private String address;

}
