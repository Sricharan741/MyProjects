package com.cognizant.mfpe.risk.pojos;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CustomerLoan {

	private Integer loanId;

	private Integer loanProductId;
	private Integer customerId;

	private Double loanPrincipal;

	private Integer tenure;

	private Double interest;

	private Double emi;

	private Integer collateralId;

	private Loan loan;

	private Customer customer;

}