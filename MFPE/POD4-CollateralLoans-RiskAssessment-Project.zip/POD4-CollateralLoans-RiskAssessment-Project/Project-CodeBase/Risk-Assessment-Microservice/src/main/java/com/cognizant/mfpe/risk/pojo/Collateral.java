package com.cognizant.mfpe.risk.pojo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

import com.sun.istack.NotNull;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ApiModel(description = "Collateral DTO")
@NoArgsConstructor
@Getter
@Setter
public class Collateral {
	@ApiModelProperty(notes = "CollateralId of Entity Collateral", name = "collateralId", dataType = "Integer")
	@NotNull
	@Positive
	private Integer collateralId;

	@ApiModelProperty(notes = "LoanId of Entity Collaterl", name = "loanId", dataType = "Integer")
	@NotNull
	@Positive
	private Integer loanId;

	@ApiModelProperty(notes = "Collateral Type like RealEstate| CashDesposti", name = "collateralType", dataType = "String")
	@NotEmpty
	@NotBlank
	private String collateralType;

	@ApiModelProperty(notes = "OwnerName of Person Who took the Collateral Loan", name = "ownername", dataType = "String")
	@NotEmpty
	@NotBlank
	private String ownerName;

	@ApiModelProperty(notes = "Address of Person", name = "address", dataType = "String")
	@NotEmpty
	@NotBlank
	private String address;

	@ApiModelProperty(notes = "CurrentValue of Collateral", name = "currentValue", dataType = "Double")
	@NotNull
	private Double currentValue;
}
