package com.cognizant.mfpe.risk.pojo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

import com.sun.istack.NotNull;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ApiModel(description = "Loan Details DTO")
@Setter
@Getter
@NoArgsConstructor
public class LoanDetailsResponseModel {
	@ApiModelProperty(notes = "LoanId  of the Customer Loan", name = "loanId", dataType = "Integer")
	@NotNull
	@Positive
	private Integer loanId;

	@ApiModelProperty(notes = "Sanctioned Loan amount", name = "sanctionedLoanAmount", dataType = "Double")
	@NotNull
	private Double sanctionedLoanAmount;

	@ApiModelProperty(notes = "Tenure  of the Customer Loan", name = "tenure", dataType = "Integer")
	@NotNull
	@Positive
	private Integer tenure;

	@ApiModelProperty(notes = "Interest Rate of the Customer Loan", name = "interest", dataType = "Double")
	@NotNull
	private Double interest;

	@ApiModelProperty(notes = "Collateral Id  of the Customer Loan", name = "collateralId", dataType = "Integer")
	@NotNull
	@Positive
	private Integer collateralId;

	@ApiModelProperty(notes = "Collateral Type like Real Estate | Cash Deposit", name = "collateralType", dataType = "String")
	@NotEmpty
	@NotBlank
	private String collateralType;
}
