package com.cognizant.mfpe.risk.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.mfpe.risk.entities.CollateralMarketValue;
import com.cognizant.mfpe.risk.entities.CollateralRisk;
import com.cognizant.mfpe.risk.exception.CollateralLoanNotFoundException;
import com.cognizant.mfpe.risk.exception.CollateralMarketValueDataNotFoundException;
import com.cognizant.mfpe.risk.exception.CollateralNotAssignedException;
import com.cognizant.mfpe.risk.exception.RiskCalculatorNotAvailableException;
import com.cognizant.mfpe.risk.feign.CollateralFeignClient;
import com.cognizant.mfpe.risk.feign.LoanFeignClient;
import com.cognizant.mfpe.risk.pojo.CollateralDetailsResponseModel;
import com.cognizant.mfpe.risk.pojo.LoanDetailsResponseModel;
import com.cognizant.mfpe.risk.pojo.RequiredCollateralDetails;
import com.cognizant.mfpe.risk.repository.CollateralMarketValueRepository;
import com.cognizant.mfpe.risk.repository.CollateralRiskRepository;

@Service
public class RiskManagementServiceImpl implements RiskManagementService {
	private static final Logger logger = LoggerFactory.getLogger(RiskManagementServiceImpl.class);
	private CollateralRiskRepository collateralRiskRepository;
	private CollateralMarketValueRepository collateralMarketValueRepository;
	private CollateralFeignClient collateralFeignClient;
	private LoanFeignClient loanFeignClient;
	private ModelMapper modelMapper;

	@Autowired
	public RiskManagementServiceImpl(CollateralRiskRepository collateralRiskRepository,
			CollateralMarketValueRepository collateralMarketValueRepository,
			CollateralFeignClient collateralFeignClient, LoanFeignClient loanFeignClient, ModelMapper modelMapper) {
		super();
		this.collateralRiskRepository = collateralRiskRepository;
		this.collateralMarketValueRepository = collateralMarketValueRepository;
		this.collateralFeignClient = collateralFeignClient;
		this.loanFeignClient = loanFeignClient;
		this.modelMapper = modelMapper;
	}

	@Override
	public CollateralRisk getCollateralRisk(Integer loanId, String requestTokenHeader) throws Exception {

		logger.info("Inside Get collateral risk method");
		CollateralMarketValue collateralMarketValueData = this.getCollateralMarketValue(loanId);
		LoanDetailsResponseModel loanDetails = this.getLoanDetailsUsingFeignClient(loanId,
				collateralMarketValueData.getCustomerId(), requestTokenHeader);
		CollateralDetailsResponseModel collateralDetailsResponseData = this.getCollateralDetailsUsingFeignClient(loanId,
				loanDetails.getCollateralId(), requestTokenHeader);

		/*
		 * Extract collateralType from collateralDetailsResponseData,
		 * collateralMarketValueData and loanDetails
		 */
		String collateralTypeInCollateralDetails = collateralDetailsResponseData.getCollateralDetails()
				.get("collateralType").toString();
		String collateralTypeInCollateralMarketValue = collateralMarketValueData.getCollateralType();
		String collateralTypeInLoanDetails = loanDetails.getCollateralType();

		logger.info("verifying all the above records are of same collatera type");
		/* verify whether all the above records have same collateralType */
		if (validateCollateralType(loanId, collateralTypeInCollateralMarketValue, collateralTypeInCollateralDetails,
				collateralTypeInLoanDetails)) {
			/*
			 * At this point all validations are satisfied. Extract collateralData from
			 * response
			 */
			Object collateralResponseData = collateralDetailsResponseData.getCollateralDetails().get("details");

			// Extract required details from collateralResponseData obtained from response
			modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
			RequiredCollateralDetails collateralDetails = modelMapper.map(collateralResponseData,
					RequiredCollateralDetails.class);

			Double newCollateralValue = this.calculateNewCollateralValue(collateralMarketValueData, collateralDetails,
					collateralTypeInLoanDetails);

			// Get sanctioned loan from loanDetails
			Double sanctionedLoan = loanDetails.getSanctionedLoanAmount();
			CollateralRisk collateralRisk = new CollateralRisk();
			if (newCollateralValue < sanctionedLoan) {
				// calculate risk %
				Double riskPercent = (double) (sanctionedLoan - newCollateralValue) * 100 / sanctionedLoan;
				collateralRisk.setRiskPercent(BigDecimal.valueOf(riskPercent).setScale(2, RoundingMode.CEILING));

			} else {
				collateralRisk.setRiskPercent(BigDecimal.ZERO);
			}
//			collateralRisk.setRiskId(1);
			collateralRisk.setLoanId(loanId);
			collateralRisk.setDateAssessed(LocalDate.now().toString());
			collateralRisk.setMarketValue(newCollateralValue);
			collateralRisk.setSanctionedLoan(sanctionedLoan);
			return collateralRiskRepository.save(collateralRisk);
		} else {
			logger.warn("Risk calculator not available for collateral type " + collateralTypeInCollateralMarketValue);
			throw new RiskCalculatorNotAvailableException(
					"Risk calculator not available for collateralType : " + collateralTypeInCollateralMarketValue
							+ "<br> [Ensure collateral type in flat file is same as collateralType in database]");
		}
	}

	@Override
	public List<CollateralMarketValue> getCollateralMarketValues() {
		logger.info("Inside Get Collateral Market Value method");
		logger.info("All collateral market values retrived");
		return collateralMarketValueRepository.findAll();
	}

	private CollateralMarketValue getCollateralMarketValue(Integer loanId) throws Exception {
		CollateralMarketValue collateralMarketValueData = collateralMarketValueRepository.findByLoanId(loanId);
		/* Checking if respective collateral market data is provided in flat file */
		logger.info("check collateral market value data null or no");
		if (collateralMarketValueData == null) {
			logger.warn("No such data exits");
			throw new CollateralMarketValueDataNotFoundException("Collateral Market value data not found for LoanId: "
					+ loanId + " [Provide market value data in flat file for loanId: " + loanId + "]");
		}
		return collateralMarketValueData;
	}

	private LoanDetailsResponseModel getLoanDetailsUsingFeignClient(Integer loanId, Integer customerId,
			String requestTokenHeader) throws Exception {
		/*
		 * Get Loan Details using loan feign client and check if collateralId is
		 * assigned
		 */
		logger.info("Get loan details using feign client");
		LoanDetailsResponseModel loanDetails = loanFeignClient.getLoanDetails(loanId, customerId, requestTokenHeader)
				.getBody();
		if (loanDetails != null && loanDetails.getCollateralId() == null || loanDetails.getCollateralId() == 0) {
			throw new CollateralNotAssignedException("Collateral not assigned for LoanId: " + loanId);
		}
		return loanDetails;
	}

	private CollateralDetailsResponseModel getCollateralDetailsUsingFeignClient(Integer loanId, Integer collateralId,
			String requestTokenHeader) throws Exception {
		logger.info("Inside get collaterals using feign method");
		/*
		 * Get collateral details using collateral feign client and check if collateral
		 * details persist in database
		 */
		logger.info("Data retrived");
		CollateralDetailsResponseModel collateralLoan = collateralFeignClient
				.getCollaterals(loanId, collateralId, requestTokenHeader).getBody();
		if (collateralLoan == null) {
			logger.warn("Collateral Details not found for particular Loan id");
			throw new CollateralLoanNotFoundException("Collateral Details not found for LoanId: " + loanId);
		}
		logger.debug("Collateral Loan Details" + collateralLoan);
		return collateralLoan;
	}

	private Boolean validateCollateralType(Integer loanId, String collateralTypeInCollateralMarketValue,
			String collateralTypeInCollateralDetails, String collateralTypeInLoanDetails) {

		logger.info("Inside validate Collateral type method");
		return (Objects.equals(collateralTypeInCollateralMarketValue, collateralTypeInCollateralDetails)
				&& Objects.equals(collateralTypeInCollateralDetails, collateralTypeInLoanDetails));
	}

	private Double calculateNewCollateralValue(CollateralMarketValue collateralMarketValueData,
			RequiredCollateralDetails collateralDetails, String collateralType) throws Exception {
		/*
		 * Calculate new currentValue for collateral based on collateralType by using
		 * collateralMarketValueData and pledged collateralDetails
		 */
		logger.info("Inside calculate collateral value method");
		Double collateralValue = collateralDetails.getCurrentValue();
		Double newCollateralValue = 0.0;
		if (collateralType.equals("REAL_ESTATE")) {
			logger.info("Collateral of type REAL_ESTATE");
			Double ratePerSqFt = collateralDetails.getRatePerSqFt();
			Double depreciationRate = collateralDetails.getDepreciationRate();

			Double newRatePerSqFt = collateralMarketValueData.getMarketValue();

			// calculate actual landValue
			Double landValue = collateralValue + (double) (collateralValue * depreciationRate) / 100;
			// calculate newLandValue
			Double newLandValue = landValue * (newRatePerSqFt / ratePerSqFt);
			newCollateralValue = newLandValue - (double) (newLandValue * depreciationRate) / 100;

		} else if (collateralType.equals("CASH_DEPOSIT")) {

			logger.info("Collateral of type CASH_DEPOSIT");
			Double depositAmount = collateralDetails.getDepositAmount();
			Integer lockPeriod = collateralDetails.getLockPeriod();

			Double newInterestRate = collateralMarketValueData.getMarketValue();

			newCollateralValue = depositAmount + (double) (depositAmount * newInterestRate * lockPeriod * 0.084) / 100;

		}
		return newCollateralValue;
	}

}
