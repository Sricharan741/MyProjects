package com.cognizant.mfpe.risk.exception;

public class CollateralMarketValueDataNotFoundException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CollateralMarketValueDataNotFoundException(String message) {
		super(message);
	}
}
