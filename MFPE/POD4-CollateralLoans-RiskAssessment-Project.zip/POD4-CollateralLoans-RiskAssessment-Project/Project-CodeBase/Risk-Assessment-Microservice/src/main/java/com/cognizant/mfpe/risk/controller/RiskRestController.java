package com.cognizant.mfpe.risk.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.mfpe.risk.entities.CollateralMarketValue;
import com.cognizant.mfpe.risk.entities.CollateralRisk;
import com.cognizant.mfpe.risk.exception.AuthorizationException;
import com.cognizant.mfpe.risk.feign.AuthorizationClient;
import com.cognizant.mfpe.risk.service.RiskManagementService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class RiskRestController {

	private static final Logger logger = LoggerFactory.getLogger(RiskRestController.class);

	private RiskManagementService riskManagementService;

	private AuthorizationClient authorizationClient;

	private Environment environment;

	@Autowired
	public RiskRestController(RiskManagementService riskManagementService, AuthorizationClient authorizationClient,
			Environment environment) {
		super();
		this.riskManagementService = riskManagementService;
		this.authorizationClient = authorizationClient;
		this.environment = environment;
	}

	@ApiOperation(value = "health-check", notes = "This method retrieves the port value")
	@ApiResponse(code = 401, message = "UnAuthorized Error")
	@GetMapping("/health-check")
	public ResponseEntity<?> healthCheck(
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader)
			throws AuthorizationException {
		logger.info("Inside HealthCheck Controller");
		logger.info("Token Checking");
		if (authorizationClient.authorizeTheRequest(requestTokenHeader)) {
			logger.info("Token Authorized ");
			logger.info("Port running on " + environment.getProperty("local.server.port"));
			return ResponseEntity.ok("Running on port :" + environment.getProperty("local.server.port"));
		} else {
			logger.warn("Token Not Authorized");
			throw new AuthorizationException("Not allowed");
		}
	}

	@ApiOperation(value = "Get-Collateral-Risk", notes = "This method retrieves the Collateral Risk Details based on loanId")
	@ApiResponses(value = { @ApiResponse(code = 401, message = "Unauthorized Error"),
			@ApiResponse(code = 400, message = "Collateral Type Not Found Exception") })
	@GetMapping(value = "/getCollateralRisk")
	public ResponseEntity<CollateralRisk> getCollateralRisk(
			@ApiParam(value = "LoanId Of Collateral Risk", name = "loanId", type = "Integer", example = "10", required = true) @RequestParam Integer loanId,
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws Exception {
		logger.info("Inside get collateral risk Controller");
		logger.info("Token Checking");
		if (authorizationClient.authorizeTheRequest(requestTokenHeader)) {
			logger.info("Token Authorized ");
			CollateralRisk collateralRisk = riskManagementService.getCollateralRisk(loanId, requestTokenHeader);
			return ResponseEntity.ok(collateralRisk);
		} else {
			logger.warn("Token Not Authorized");
			throw new AuthorizationException("Not allowed");
		}
	}

	@ApiOperation(value = "Get-Collateral-Market-Value", notes = "This method retrieves all Updated market Values")
	@ApiResponses(value = { @ApiResponse(code = 401, message = "Unauthorized Error"),
			@ApiResponse(code = 400, message = "No Update found") })
	@GetMapping(value = "/getCollateralMarketValues")
	public ResponseEntity<List<CollateralMarketValue>> getCollateralMarketValues(
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws Exception {
		logger.info("Inside get collateral market value Controller");
		logger.info("Token Checking");
		if (authorizationClient.authorizeTheRequest(requestTokenHeader)) {
			logger.info("Token Authorized ");
			return ResponseEntity.ok().body(riskManagementService.getCollateralMarketValues());
		} else {
			logger.warn("Token Not Authorized");
			throw new AuthorizationException("Not allowed");
		}

	}

}
