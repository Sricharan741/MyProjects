package com.cognizant.mfpe.risk.exception;

/**
 * Class for handling CollateralAlreadyExistsException
 *
 */

public class CollateralLoanNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	/**
	 * Constructor
	 * 
	 * @param message
	 */
	public CollateralLoanNotFoundException(String message) {
		super(message);
	}
}
