package com.cognizant.mfpe.risk.pojo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

import com.sun.istack.NotNull;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ApiModel(description = "Collateral Cash Deposti DTO")
@NoArgsConstructor
@Getter
@Setter
public class CollateralCashDeposit extends Collateral {

	@ApiModelProperty(notes = "BankName in which Collateral type Cash Deposit was Stored", name = "bankName", dataType = "String")
	@NotEmpty
	@NotBlank
	private String bankName;

	@ApiModelProperty(notes = "InterestRate of Collateral Cash Deposit", name = "interestRate", dataType = "Double")
	@NotNull
	private Double interestRate;

	@ApiModelProperty(notes = "DepositAmount of Collateral Cash Deposit", name = "depositAmount", dataType = "Double")
	@NotNull
	private Double depositAmount;

	@ApiModelProperty(notes = "LockPeriod of Collateral Cash Deposit", name = "lockPeriod", dataType = "Integer")
	@NotNull
	@Positive
	private Integer lockPeriod;
}
