package com.cognizant.mfpe.risk.exception;

/**
 * Class for handling CollateralAlreadyExistsException
 *
 */
public class CollateralNotAssignedException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	/**
	 * Constructor
	 * 
	 * @param message
	 */
	public CollateralNotAssignedException(String message) {
		super(message);
	}
}
