package com.cognizant.mfpe.risk.exception;

public class RiskCalculatorNotAvailableException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RiskCalculatorNotAvailableException(String message) {
		super(message);
	}
}
