package com.cognizant.mfpe.risk.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@ApiModel(description = "Details about Updated Collateral Values Based on Market")
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder
public class CollateralMarketValue {

	@ApiModelProperty(notes = "Auto-Generated key value", name = "sNo", dataType = "Integer")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer sNo;

	@ApiModelProperty(notes = "Loan Id of the Customer whoose collateral Value needed to be updated", name = "collateralId", dataType = "Integer")
	private Integer loanId;

	@ApiModelProperty(notes = "Customer Id to which Collateral need to be updated based on loanid of the customer", name = "customerId", dataType = "Integer")
	private Integer customerId;

	@ApiModelProperty(notes = "Type of the Collateral : CashDeposit | RealEstate", name = "collateralType", dataType = "String")
	private String collateralType;

	@ApiModelProperty(notes = "Updated Market value of the collateral", name = "marketValue", dataType = "Double")
	private Double marketValue;

}