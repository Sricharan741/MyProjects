insert into users (id, password, user_name) values (1, '$2a$10$BhBZRNJZKsGHc4K6oC64w.EQWT7mb2DcgBXT0CkJMBxJDLHIfkCkK', 'admin');
insert into users (id, password, user_name) values (2, '$2a$10$eMHtwv3EL/xLToOoANS7aOrvsdHYWmBxgyyCFl54feX366SxqZft.', 'user1');
insert into users (id, password, user_name) values (3, '$2a$10$7HwwTTx2BvBSCd1bVyLgaOAIDPzSvOyuWKx9Nf1znXWURzuPYAOki', 'user2');

/*
 * 			LOGIN - CREDENTIALS
 * 	UserName = admin , Password = password
 *	UserName = user1 , Password = user1password
 *	UserName = user2 , Password = user2password 
 */
