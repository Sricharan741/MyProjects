package com.cognizant.mfpe.loan.ui;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@ApiModel(description = "Details of LoanDetailsResponseModel")
public class LoanDetailsResponseModel {
	@ApiModelProperty(notes = "LoanId  of the Loan", name = "loanId", dataType = "Integer")
	private Integer loanId;
	@ApiModelProperty(notes = "Sanctioned Loan Amount  of the Loan", name = "sanctionedLoanAmount", dataType = "Double")
	private Double sanctionedLoanAmount;
	@ApiModelProperty(notes = "Tenure of the loan", name = "tenure", dataType = "Integer")
	private Integer tenure;
	@ApiModelProperty(notes = "Interest rate of the Loan", name = "interest", dataType = "Double")
	private Double interest;
	@ApiModelProperty(notes = "Collateral Id of the Loan", name = "collateralId", dataType = "Integer")
	private Integer collateralId;
	@ApiModelProperty(notes = "CollateralType of the Loan", name = "collateralType", dataType = "CollateralType")
	private String collateralType;
}
