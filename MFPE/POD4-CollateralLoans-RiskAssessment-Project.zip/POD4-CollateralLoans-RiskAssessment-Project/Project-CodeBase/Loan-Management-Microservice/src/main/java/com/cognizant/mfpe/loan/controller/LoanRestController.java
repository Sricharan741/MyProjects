package com.cognizant.mfpe.loan.controller;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.mfpe.loan.entities.Customer;
import com.cognizant.mfpe.loan.entities.CustomerLoan;
import com.cognizant.mfpe.loan.entities.Loan;
import com.cognizant.mfpe.loan.exception.AuthorizationException;
import com.cognizant.mfpe.loan.feign.AuthorizationClient;
import com.cognizant.mfpe.loan.pojo.CollateralType;
import com.cognizant.mfpe.loan.service.LoanManagementService;
import com.cognizant.mfpe.loan.ui.CollateralDetailsRequestModel;
import com.cognizant.mfpe.loan.ui.LoanDetailsResponseModel;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class LoanRestController {

	private static final Logger logger = LoggerFactory.getLogger(LoanRestController.class);

	private LoanManagementService service;

	private Environment environment;

	private ModelMapper modelMapper;

	private AuthorizationClient authorizationClient;

	@Autowired
	public LoanRestController(LoanManagementService service, Environment environment, ModelMapper modelMapper,
			AuthorizationClient authorizationClient) {
		super();
		this.service = service;
		this.environment = environment;
		this.modelMapper = modelMapper;
		this.authorizationClient = authorizationClient;
	}

	@ApiOperation(value = "health-check", notes = "This method retrieves the port number")
	@ApiResponse(code = 401, message = "UnAuthorized Error")
	@GetMapping("/health-check")
	public ResponseEntity<?> healthCheck(
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader)
			throws AuthorizationException {
		logger.info("Inside HealthCheck Controller");
		logger.info("Token Checking");
		if (authorizationClient.authorizeTheRequest(requestTokenHeader)) {
			logger.info("Token Authorized ");
			logger.info("Port running on " + environment.getProperty("local.server.port"));
			return ResponseEntity.ok("Running on port :" + environment.getProperty("local.server.port"));
		} else {
			logger.warn("Token Not Authorized");
			throw new AuthorizationException("Not allowed");
		}
	}

	@ApiOperation(value = "getLoanDetails", notes = "This method retrieves Loan Details by loanId and customerId", response = CustomerLoan.class)
	@ApiResponses(value = { @ApiResponse(code = 401, message = "UnAuthorized Error"),
			@ApiResponse(code = 404, message = "Customer Loan Not Found ") })
	@GetMapping("/getLoanDetails")
	public ResponseEntity<LoanDetailsResponseModel> getLoanDetails(
			@ApiParam(value = "LoanId", name = "loanId", type = "Integer", example = "10", required = true) @RequestParam Integer loanId,
			@ApiParam(value = "CustomerId", name = "customerId", type = "Integer", example = "10", required = true) @RequestParam Integer customerId,
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws Exception {
		logger.info("Inside get loan details Controller");
		logger.info("Token Checking");
		if (authorizationClient.authorizeTheRequest(requestTokenHeader)) {
			logger.info("Token Authorized ");
			CustomerLoan customerLoan = service.getLoanDetails(loanId, customerId);
			modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
			LoanDetailsResponseModel responseModel = modelMapper.map(customerLoan, LoanDetailsResponseModel.class);
			responseModel.setSanctionedLoanAmount(customerLoan.getLoanPrincipal());
			responseModel.setCollateralType(customerLoan.getLoan().getCollateralType());
			logger.info("Loan Details retrived");
			return ResponseEntity.ok(responseModel);
		} else {
			logger.info("Token unauthorized");
			throw new AuthorizationException("Not allowed");
		}

	}

	@ApiOperation(value = "saveCollaterals", notes = "This method stores Collateral Details")
	@ApiResponses(value = { @ApiResponse(code = 401, message = "UnAuthorized Error"),
			@ApiResponse(code = 400, message = "Collateral Already Assigned or Collateral Not Acceptable") })
	@PostMapping("/saveCollaterals/{loanId}/{collateralId}/{collateralType}")
	public ResponseEntity<Boolean> saveCollaterals(
			@ApiParam(value = "LoanId", name = "loanId", type = "Integer", example = "10", required = true) @PathVariable Integer loanId,
			@ApiParam(value = "CollateralId", name = "collateralId", type = "Integer", example = "10", required = true) @PathVariable Integer collateralId,
			@ApiParam(value = "CollateralType", name = "collateralType", type = "CollateralType", example = "CASH_DEPOSIT", required = true) @PathVariable CollateralType collateralType,
			@RequestBody CollateralDetailsRequestModel requestModel,
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws Exception {
		logger.info("Inside get save collateral details Controller");
		logger.info("Token Checking");
		if (authorizationClient.authorizeTheRequest(requestTokenHeader)) {
			logger.info("Token Authorized ");
			logger.info("Collateral Details are saved");
			return ResponseEntity.ok(
					service.saveCollaterals(loanId, collateralId, collateralType, requestModel, requestTokenHeader));
		} else {
			logger.info("Token unauthorized");
			throw new AuthorizationException("Not allowed");
		}
	}

	// Get All Customers

	@ApiOperation(value = "getAllCustomers", notes = "This method retrives all Customers")
	@ApiResponses(value = { @ApiResponse(code = 401, message = "UnAuthorized Error"),
			@ApiResponse(code = 400, message = "No Customers available") })
	@GetMapping("/getAllCustomers")
	public ResponseEntity<List<Customer>> getAllCustomers(
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws Exception {
		logger.info("Inside get customer Controller");
		logger.info("Token Checking");
		if (authorizationClient.authorizeTheRequest(requestTokenHeader)) {
			logger.info("Token Authorized ");
			logger.info("All customers are retrived");
			return ResponseEntity.ok(service.getAllCustomers());
		} else {
			logger.info("Token unauthorized");
			throw new AuthorizationException("Not allowed");
		}
	}

	// Get All Products
	@ApiOperation(value = "getAllLoanProducts", notes = "This method retrives all Loans given on different Products")
	@ApiResponses(value = { @ApiResponse(code = 401, message = "UnAuthorized Error"),
			@ApiResponse(code = 400, message = "No Loan Products available") })
	@GetMapping("/getAllLoanProducts")
	public ResponseEntity<List<Loan>> getAllLoanProducts(
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws Exception {
		logger.info("Inside get all loan products Controller");
		logger.info("Token Checking");
		if (authorizationClient.authorizeTheRequest(requestTokenHeader)) {
			logger.info("Token Authorized ");
			logger.info("All Loan Product are retrived");
			return ResponseEntity.ok(service.getAllProducts());
		} else {
			logger.info("Token unauthorized");
			throw new AuthorizationException("Not allowed");
		}

	}

}
