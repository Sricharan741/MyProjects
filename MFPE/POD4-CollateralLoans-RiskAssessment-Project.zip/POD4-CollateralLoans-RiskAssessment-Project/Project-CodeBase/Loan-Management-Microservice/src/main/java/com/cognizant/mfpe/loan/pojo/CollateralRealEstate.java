package com.cognizant.mfpe.loan.pojo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ApiModel(description = "Details of Real Estate Collateral")
@NoArgsConstructor
@Getter
@Setter
public class CollateralRealEstate extends Collateral {

	@ApiModelProperty(notes = "Rate Per Square Feet of the Property or Asset", name = "ratePerSqFt", dataType = "Double")
	private Double ratePerSqFt;
	@ApiModelProperty(notes = "Depreciation rate is the percentage rate at which asset is depreciated across the estimated productive life of the asset", name = "depreciationRate", dataType = "Double")
	private Double depreciationRate;
}
