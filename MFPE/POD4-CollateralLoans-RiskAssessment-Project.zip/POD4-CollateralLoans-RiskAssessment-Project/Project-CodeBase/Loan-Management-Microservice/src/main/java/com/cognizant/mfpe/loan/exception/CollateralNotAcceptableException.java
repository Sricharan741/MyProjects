package com.cognizant.mfpe.loan.exception;

public class CollateralNotAcceptableException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CollateralNotAcceptableException(String message) {
		super(message);
	}
}
