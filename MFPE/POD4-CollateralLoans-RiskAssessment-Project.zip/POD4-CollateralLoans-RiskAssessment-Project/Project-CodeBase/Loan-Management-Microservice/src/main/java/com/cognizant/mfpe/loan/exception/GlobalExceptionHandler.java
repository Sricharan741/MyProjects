package com.cognizant.mfpe.loan.exception;

import java.time.LocalDateTime;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import feign.FeignException;
import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(CustomerLoanNotFoundException.class)
	public ResponseEntity<ApiErrorResponse> handleNotFoundException(Exception ex, WebRequest request) {
		log.error(ex.getMessage());
		ApiErrorResponse errorResponse = new ApiErrorResponse(LocalDateTime.now(), HttpStatus.NOT_FOUND);
		errorResponse.setMessage(ex.getMessage());
		errorResponse.setLocalizedMessage(ex.getLocalizedMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler({ Exception.class, MissingRequestHeaderException.class, CollateralAlreadyAssignedException.class,
			CollateralNotAcceptableException.class })

	public ResponseEntity<ApiErrorResponse> handleAnyException(Exception ex, WebRequest request) {
		log.error(ex.getMessage());
		ApiErrorResponse errorResponse = new ApiErrorResponse(LocalDateTime.now(), HttpStatus.BAD_REQUEST);
		errorResponse.setLocalizedMessage(ex.getLocalizedMessage());
		errorResponse.setMessage(ex.getMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public ResponseEntity<ApiErrorResponse> handleMethodArgumentTypeMismatchException(Exception ex,
			WebRequest request) {
		log.error(ex.getMessage());
		ApiErrorResponse errorResponse = new ApiErrorResponse(LocalDateTime.now(), HttpStatus.BAD_REQUEST);
		errorResponse.setLocalizedMessage("Invalid Collateral Type for given loanId");
		errorResponse.setMessage("Invalid Collateral Type for given loanId");
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(AuthorizationException.class)
	public ResponseEntity<ApiErrorResponse> handleGlobalException(AuthorizationException ex, WebRequest request) {
		log.error(ex.getMessage());
		ApiErrorResponse errorResponse = new ApiErrorResponse(LocalDateTime.now(), HttpStatus.UNAUTHORIZED);
		errorResponse.setLocalizedMessage(ex.getLocalizedMessage());
		errorResponse.setMessage(ex.getMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(FeignException.class)
	public Map<String, Object> handleFeignStatusException(FeignException e, HttpServletResponse response) {
		log.error(e.contentUTF8());
		response.setStatus(e.status());
		return new JSONObject(e.contentUTF8()).toMap();
	}
}
