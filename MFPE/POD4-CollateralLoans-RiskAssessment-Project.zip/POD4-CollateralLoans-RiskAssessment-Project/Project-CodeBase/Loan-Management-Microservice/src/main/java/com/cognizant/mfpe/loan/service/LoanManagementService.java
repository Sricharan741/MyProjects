package com.cognizant.mfpe.loan.service;

import java.util.List;

import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.cognizant.mfpe.loan.entities.Customer;
import com.cognizant.mfpe.loan.entities.CustomerLoan;
import com.cognizant.mfpe.loan.entities.Loan;
import com.cognizant.mfpe.loan.exception.CollateralAlreadyAssignedException;
import com.cognizant.mfpe.loan.exception.CollateralNotAcceptableException;
import com.cognizant.mfpe.loan.exception.CustomerLoanNotFoundException;
import com.cognizant.mfpe.loan.pojo.CollateralType;
import com.cognizant.mfpe.loan.ui.CollateralDetailsRequestModel;

public interface LoanManagementService {

	public CustomerLoan getLoanDetails(Integer loanId, Integer customerId) throws CustomerLoanNotFoundException;

	public Boolean saveCollaterals(Integer loanId, Integer collateralId, CollateralType collateralType,
			CollateralDetailsRequestModel requestModel, String requestTokenHeader)
			throws CollateralAlreadyAssignedException, CollateralNotAcceptableException,
			MethodArgumentTypeMismatchException,CustomerLoanNotFoundException;

	public List<Customer> getAllCustomers();

	public List<Loan> getAllProducts();

}
