package com.cognizant.mfpe.loan.service;

import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.cognizant.mfpe.loan.entities.Customer;
import com.cognizant.mfpe.loan.entities.CustomerLoan;
import com.cognizant.mfpe.loan.entities.Loan;
import com.cognizant.mfpe.loan.exception.CollateralAlreadyAssignedException;
import com.cognizant.mfpe.loan.exception.CollateralNotAcceptableException;
import com.cognizant.mfpe.loan.exception.CustomerLoanNotFoundException;
import com.cognizant.mfpe.loan.feign.CollateralFeignClient;
import com.cognizant.mfpe.loan.pojo.CollateralType;
import com.cognizant.mfpe.loan.repository.CustomerLoanRepository;
import com.cognizant.mfpe.loan.repository.CustomerRepository;
import com.cognizant.mfpe.loan.repository.LoanRepository;
import com.cognizant.mfpe.loan.ui.CollateralDetailsRequestModel;

@Service
public class LoanManagementServiceImpl implements LoanManagementService {

	private static final Logger logger = LoggerFactory.getLogger(LoanManagementServiceImpl.class);

	private CollateralFeignClient collateralFeignClient;

	private CustomerLoanRepository customerLoanRepository;

	private Random random;

	private CustomerRepository customerRepository;

	private LoanRepository loanRepository;

	@Autowired
	public LoanManagementServiceImpl(CollateralFeignClient collateralFeignClient,
			CustomerLoanRepository customerLoanRepository, CustomerRepository customerRepository,
			LoanRepository loanRepository) {
		super();
		this.collateralFeignClient = collateralFeignClient;
		this.customerLoanRepository = customerLoanRepository;
		random = new Random();
		this.customerRepository = customerRepository;
		this.loanRepository = loanRepository;
	}

	@Override
	public CustomerLoan getLoanDetails(Integer loanId, Integer customerId) throws CustomerLoanNotFoundException {
		CustomerLoan customerLoan = customerLoanRepository.findByLoanIdAndCustomerId(loanId, customerId);
		if (customerLoan == null) {
			logger.warn("No such Loan details found");
			throw new CustomerLoanNotFoundException(
					"Customer Loan Details not found for customer with LoanId: " + loanId);
		}
		return customerLoan;
	}

	@Override
	public Boolean saveCollaterals(Integer loanId, Integer collateralId, CollateralType collateralType,
			CollateralDetailsRequestModel requestModel, String requestTokenHeader)
			throws CollateralAlreadyAssignedException, CollateralNotAcceptableException,
			MethodArgumentTypeMismatchException,CustomerLoanNotFoundException {

		Optional<CustomerLoan> optional = customerLoanRepository.findById(loanId);
		CustomerLoan customerLoan = null;
		if (optional.isPresent()) {
			customerLoan = optional.get();
		} else {
			logger.warn("No such Loan details found");
			throw new CustomerLoanNotFoundException(
					"Customer Loan Details not found for customer with LoanId: " + loanId);
		}
		/*
		 * Move forward to assign a collateralId if given collateralId is NULL and the
		 * givencollateralType matches with taken loanProduct collateraType
		 * 
		 */
		if ((collateralId == null || collateralId == 0) && customerLoan.getCollateralId() == null
				&& collateralType.name().equals(customerLoan.getLoan().getCollateralType())) {
			logger.info("No such Collateral Details exixts. Collateral Details need to be stored");

			Double collateralValue = this.calculateCollateralValue(collateralType, requestModel);

			/*
			 * Check whether respective collateral can be accepted or not by using
			 * currentValue of collateral
			 */
			Double collateralCoverage = 1.2;
			logger.info("Checking collatera value >= product of loan principa and collateral coverage");
			if (collateralValue >= customerLoan.getLoanPrincipal() * collateralCoverage) {
				/*
				 * Update CollateralDetailsRequestModel. Get customer details to assign
				 * ownerName, ownerAddress and currentValue into requestModel
				 */
				requestModel = this.assignOwnerDetailsAndCurrentValueAndCollateralValue(requestModel, customerLoan,
						collateralValue, collateralType.name());

				// Assign collateralId to customerLoan table
				collateralId = this.generateRandomCollateralId();
				logger.info(collateralId+"");
				this.assignCollateralIdToCustomerLoan(customerLoan, collateralId);
				// Save the collateral Details by using feign client
				return collateralFeignClient
						.saveCollaterals(loanId, collateralId, collateralType, requestModel, requestTokenHeader)
						.getBody();
			} else {
				throw new CollateralNotAcceptableException(String.format(
						"Collateral not acceptable for LoanId : %d [Provided collateralValue(%.2f) must be greater than %.1f times loan Principal(%.2f)]",
						loanId, collateralValue, collateralCoverage, customerLoan.getLoanPrincipal()));
			}
		} else {
			logger.info("Collateral already asssigned");
			throw new CollateralAlreadyAssignedException("Collateral already assigned for LoanId : " + loanId);
		}
	}

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customerRepository.findAll();
	}

	@Override
	public List<Loan> getAllProducts() {
		// TODO Auto-generated method stub
		return loanRepository.findAll();
	}

	private Integer generateRandomCollateralId() {
		return random.nextInt(1000) + 1;
	}

	private void assignCollateralIdToCustomerLoan(CustomerLoan customerLoan, Integer collateralId) {
		customerLoan.setCollateralId(collateralId);
		customerLoanRepository.save(customerLoan);
	}

	private Double calculateCollateralValue(CollateralType collateralType,
			CollateralDetailsRequestModel collateralDetails) {
		// Estimate currentValue of given collateral based on collateralType
		Double collateralValue = 0.0;
		if (collateralType.equals(CollateralType.CASH_DEPOSIT)) {
			Double interestRate = collateralDetails.getInterestRate();
			Double depositAmount = collateralDetails.getDepositAmount();
			Integer lockPeriod = collateralDetails.getLockPeriod();
			collateralValue = depositAmount + (double) (depositAmount * interestRate * lockPeriod * 0.084) / 100;
		} else if (collateralType.equals(CollateralType.REAL_ESTATE)) {
			Double currentValue = collateralDetails.getCurrentValue();
			Double depreciationRate = collateralDetails.getDepreciationRate();
			collateralValue = currentValue - (double) (currentValue * depreciationRate) / 100;
		}
		return collateralValue;
	}

	private CollateralDetailsRequestModel assignOwnerDetailsAndCurrentValueAndCollateralValue(
			CollateralDetailsRequestModel requestModel, CustomerLoan customerLoan, Double collateralValue,
			String collateralType) {
		Customer customer = customerLoan.getCustomer();
		requestModel.setOwnerName(customer.getName());
		requestModel.setAddress(customer.getAddress());
		requestModel.setCollateralValue(collateralValue);
		if (collateralType.equals("REAL_ESTATE")) {
			requestModel.setCurrentValue(requestModel.getCurrentValue());
		} else if (collateralType.equals("CASH_DEPOSIT")) {
			requestModel.setCurrentValue(collateralValue);
		}
		return requestModel;
	}

}
