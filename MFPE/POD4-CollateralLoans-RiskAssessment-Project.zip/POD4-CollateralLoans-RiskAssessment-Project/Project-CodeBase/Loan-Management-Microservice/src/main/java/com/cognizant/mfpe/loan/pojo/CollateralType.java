package com.cognizant.mfpe.loan.pojo;

import io.swagger.annotations.ApiModel;

@ApiModel(description = "Collateral Type values are REAL_ESTATE,CASH_DEPOSIT")
public enum CollateralType {
	REAL_ESTATE, CASH_DEPOSIT
}
