package com.cognizant.mfpe.loan.pojo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ApiModel(description = "Details of Collateral CashDeposit")
@NoArgsConstructor
@Getter
@Setter
public class CollateralCashDeposit extends Collateral {
	@ApiModelProperty(notes = "BankName of Collateral Cash Deposit", name = "bankName", dataType = "String")
	private String bankName;
	@ApiModelProperty(notes = "InterestRate of Collateral Cash Deposit", name = "interestRate", dataType = "Double")
	private Double interestRate;
	@ApiModelProperty(notes = "DepositAmount of Collateral Cash Deposit", name = "depositAmount", dataType = "Double")
	private Double depositAmount;
	@ApiModelProperty(notes = "LockPeriod of Collateral Cash Deposit", name = "lockPeriod", dataType = "Integer")
	private Integer lockPeriod;
}
