package com.cognizant.mfpe.loan.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.mfpe.loan.entities.CustomerLoan;

@Repository
public interface CustomerLoanRepository extends JpaRepository<CustomerLoan, Integer> {
	public CustomerLoan findByLoanIdAndCustomerId(Integer loanId, Integer customerId);
}
