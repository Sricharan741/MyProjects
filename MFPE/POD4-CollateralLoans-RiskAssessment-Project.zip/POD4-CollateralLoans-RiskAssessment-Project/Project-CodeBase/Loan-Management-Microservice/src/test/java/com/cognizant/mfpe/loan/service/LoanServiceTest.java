package com.cognizant.mfpe.loan.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.cognizant.mfpe.loan.entities.Customer;
import com.cognizant.mfpe.loan.entities.CustomerLoan;
import com.cognizant.mfpe.loan.entities.Loan;
import com.cognizant.mfpe.loan.exception.CollateralAlreadyAssignedException;
import com.cognizant.mfpe.loan.exception.CollateralNotAcceptableException;
import com.cognizant.mfpe.loan.exception.CustomerLoanNotFoundException;
import com.cognizant.mfpe.loan.feign.CollateralFeignClient;
import com.cognizant.mfpe.loan.pojo.CollateralCashDeposit;
import com.cognizant.mfpe.loan.pojo.CollateralRealEstate;
import com.cognizant.mfpe.loan.pojo.CollateralType;
import com.cognizant.mfpe.loan.repository.CustomerLoanRepository;
import com.cognizant.mfpe.loan.repository.CustomerRepository;
import com.cognizant.mfpe.loan.repository.LoanRepository;
import com.cognizant.mfpe.loan.ui.CollateralDetailsRequestModel;

import lombok.extern.slf4j.Slf4j;

/**
 * Test - LoanService Test class
 */
@SpringBootTest
@RunWith(SpringRunner.class)
@Slf4j
class LoanServiceTest {

	@MockBean
	private CollateralFeignClient collateralFeignClient;

	@MockBean
	private CustomerLoanRepository customerLoanRepository;

	@MockBean
	private CustomerRepository customerRepository;

	@MockBean
	private LoanRepository loanRepository;

	@InjectMocks
	@Autowired
	private LoanManagementServiceImpl service;

	private static CollateralRealEstate realEstate;
	private static CollateralCashDeposit cashDeposit;
	private static CollateralDetailsRequestModel requestModelRealEstate;
	private static CollateralDetailsRequestModel requestModelCashDeposit;
	private static Customer customer1;
	private static Customer customer2;
	private static Loan loanProduct1;
	private static Loan loanProduct2;
	private static CustomerLoan custLoan1;
	private static CustomerLoan custLoan2;

	@BeforeAll
	static void init() {
		log.info("Initializing data...");
		ModelMapper modelMapper = new ModelMapper();
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);

		realEstate = new CollateralRealEstate();
		realEstate.setCollateralId(123);
		realEstate.setCollateralType(CollateralType.REAL_ESTATE.name());
		realEstate.setCurrentValue(4000000.0);
		realEstate.setDepreciationRate(5.0);
		realEstate.setLoanId(10001);
		realEstate.setAddress("Kolkata");
		realEstate.setOwnerName("Himashu");
		realEstate.setRatePerSqFt(5000.0);

		cashDeposit = new CollateralCashDeposit();
		cashDeposit.setCollateralId(456);
		cashDeposit.setCollateralType(CollateralType.CASH_DEPOSIT.name());
		cashDeposit.setCurrentValue(2000000.0);
		cashDeposit.setDepositAmount(8000000.0);
		cashDeposit.setInterestRate(15.0);
		cashDeposit.setLoanId(10001);
		cashDeposit.setLockPeriod(10);
		cashDeposit.setAddress("Kolkata");
		cashDeposit.setOwnerName("Himashu");

		requestModelRealEstate = modelMapper.map(realEstate, CollateralDetailsRequestModel.class);
		requestModelCashDeposit = modelMapper.map(cashDeposit, CollateralDetailsRequestModel.class);

		customer1 = new Customer();
		customer1.setCustomerId(101);
		customer1.setName("Sampath");
		customer1.setEmailId("sampath123@gmail.com");
		customer1.setMobileNo("7780184807");
		customer1.setAddress("Vijayawada");

		customer2 = new Customer();
		customer2.setCustomerId(102);
		customer2.setName("Sricharan");
		customer2.setEmailId("sricharan123@gmail.com");
		customer2.setMobileNo("9874561231");
		customer2.setAddress("Kolkata");

		loanProduct1 = new Loan();
		loanProduct1.setLoanProductId(1001);
		loanProduct1.setLoanProductName("Home Loan");
		loanProduct1.setMaxLoanEligible(3000000.00);
		loanProduct1.setInterestRate(10.5);
		loanProduct1.setTenure(48);
		loanProduct1.setCollateralType("REAL_ESTATE");

		loanProduct2 = new Loan();
		loanProduct2.setLoanProductId(1002);
		loanProduct2.setLoanProductName("Home Loan");
		loanProduct2.setMaxLoanEligible(1100000.00);
		loanProduct2.setInterestRate(9.5);
		loanProduct2.setTenure(40);
		loanProduct2.setCollateralType("CASH_DEPOSIT");

		custLoan1 = new CustomerLoan();
		custLoan1.setLoanId(10001);
		custLoan1.setLoanProductId(1001);
		custLoan1.setCustomerId(101);
		custLoan1.setLoanPrincipal(2500000.0);
		custLoan1.setTenure(48);
		custLoan1.setInterest(10.5);
		custLoan1.setEmi(64008.0);
		custLoan1.setCollateralId(null);
		custLoan1.setLoan(loanProduct1);
		custLoan1.setCustomer(customer1);

		custLoan2 = new CustomerLoan();
		custLoan2.setLoanId(10002);
		custLoan2.setLoanProductId(1002);
		custLoan2.setCustomerId(102);
		custLoan2.setLoanPrincipal(900000.0);
		custLoan2.setTenure(40);
		custLoan2.setInterest(9.5);
		custLoan2.setEmi(26338.0);
		custLoan2.setCollateralId(null);
		custLoan2.setLoan(loanProduct2);
		custLoan2.setCustomer(customer2);
	}

	@Test
	void testGetLoanDetailsUsingLoanIdAndCustomerId() throws Exception {
		log.info("testGetLoanDetailsUsingLoanIdAndCustomerId");
		customerLoanRepository.save(custLoan1);
		when(customerLoanRepository.findByLoanIdAndCustomerId(10001, 101)).thenReturn(custLoan1);
		assertThat(service.getLoanDetails(10001, 101)).isEqualTo(custLoan1);
	}

	@Test
	void testGetLoanNotFoundExceptionForCustomerLoanUsingLoanIdAndCustomerId() throws Exception {
		log.info("testGetLoanNotFoundExceptionForCustomerLoanUsingLoanIdAndCustomerId");
		customerLoanRepository.save(custLoan1);
		when(customerLoanRepository.findByLoanIdAndCustomerId(10001, 999)).thenReturn(null);
		assertThrows(CustomerLoanNotFoundException.class, () -> service.getLoanDetails(10001, 999));
	}

	@Test
	void testSaveValidRealEstateCollateralDetails() throws Exception {
		log.info("testSaveValidRealEstateCollateralDetails");
		customerLoanRepository.save(custLoan1);
		when(customerLoanRepository.findById(10001)).thenReturn(Optional.of(custLoan1));
		when(collateralFeignClient.saveCollaterals(10001, 999, CollateralType.REAL_ESTATE, requestModelRealEstate,
				"token")).thenReturn(ResponseEntity.ok(true));
		assertThrows(NullPointerException.class,
				() -> service.saveCollaterals(10001, 0, CollateralType.REAL_ESTATE, requestModelRealEstate, "token"));
	}

	@Test
	void testSaveValidCashDepositCollateralDetails() throws Exception {
		log.info("testSaveValidCashDepositCollateralDetails");
		customerLoanRepository.save(custLoan2);
		when(customerLoanRepository.findById(10002)).thenReturn(Optional.of(custLoan2));
		when(collateralFeignClient.saveCollaterals(10002, 999, CollateralType.CASH_DEPOSIT, requestModelCashDeposit,
				"token")).thenReturn(ResponseEntity.ok(true));
		assertThrows(NullPointerException.class,
				() -> service.saveCollaterals(10002, 0, CollateralType.CASH_DEPOSIT, requestModelCashDeposit, "token"));
	}

	@Test
	void handlesCollateralAlreadyAssignedExceptionTest() {
		log.info("handlesCollateralAlreadyAssignedExceptionTest");
		customerLoanRepository.save(custLoan2);
		when(customerLoanRepository.findById(10002)).thenReturn(Optional.of(custLoan2));
		assertThrows(CollateralAlreadyAssignedException.class,
				() -> service.saveCollaterals(10002, 0, CollateralType.CASH_DEPOSIT, requestModelCashDeposit, "token"));
	}

	@Test
	void handlesCollateralNotAcceptableExceptionTest() {
		log.info("handlesCollateralNotAcceptableExceptionTest");
		customerLoanRepository.save(custLoan2);
		when(customerLoanRepository.findById(10002)).thenReturn(Optional.of(custLoan2));
		requestModelCashDeposit.setDepositAmount(80.0);
		assertThrows(CollateralNotAcceptableException.class,
				() -> service.saveCollaterals(10002, 0, CollateralType.CASH_DEPOSIT, requestModelCashDeposit, "token"));
		requestModelCashDeposit.setDepositAmount(8000000.0);
	}

	@Test
	void handlesCustomerLoanNotFoundExceptionTest() {
		log.info("handlesCustomerLoanNotFoundExceptionTest");
		customerLoanRepository.save(custLoan2);
		when(customerLoanRepository.findById(10002)).thenReturn(Optional.of(custLoan2));
		assertThrows(CustomerLoanNotFoundException.class,
				() -> service.saveCollaterals(10003, 0, CollateralType.CASH_DEPOSIT, requestModelCashDeposit, "token"));
	}

	@Test
	void testGetAllCustomers() {
		log.info("testGetAllCustomers");
		customerRepository.save(customer1);
		customerRepository.save(customer2);
		List<Customer> list = new ArrayList<>();
		list.add(customer1);
		list.add(customer2);
		when(customerRepository.findAll()).thenReturn(list);
		assertEquals(list.size(), service.getAllCustomers().size());
	}

	@Test
	void testgetAllProducts() {
		log.info("testgetAllProducts");
		loanRepository.save(loanProduct1);
		loanRepository.save(loanProduct2);
		List<Loan> list = new ArrayList<>();
		list.add(loanProduct1);
		list.add(loanProduct2);
		when(loanRepository.findAll()).thenReturn(list);
		assertEquals(list.size(), service.getAllProducts().size());
	}
}
