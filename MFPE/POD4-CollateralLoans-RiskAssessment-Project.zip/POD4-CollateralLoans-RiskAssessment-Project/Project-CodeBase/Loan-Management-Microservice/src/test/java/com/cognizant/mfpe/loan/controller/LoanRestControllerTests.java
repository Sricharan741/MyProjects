package com.cognizant.mfpe.loan.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.cognizant.mfpe.loan.entities.Customer;
import com.cognizant.mfpe.loan.entities.CustomerLoan;
import com.cognizant.mfpe.loan.entities.Loan;
import com.cognizant.mfpe.loan.exception.CustomerLoanNotFoundException;
import com.cognizant.mfpe.loan.feign.AuthorizationClient;
import com.cognizant.mfpe.loan.pojo.CollateralCashDeposit;
import com.cognizant.mfpe.loan.pojo.CollateralRealEstate;
import com.cognizant.mfpe.loan.pojo.CollateralType;
import com.cognizant.mfpe.loan.service.LoanManagementService;
import com.cognizant.mfpe.loan.ui.CollateralDetailsRequestModel;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * Test - LoanRestController class
 */
@RunWith(SpringRunner.class)
@WebMvcTest(LoanRestController.class)
@Slf4j
class LoanRestControllerTests {

	@Autowired
	private MockMvc mvc;

	@MockBean
	private LoanManagementService service;

	@MockBean
	private AuthorizationClient authclient;

	private static CollateralRealEstate realEstate;
	private static CollateralCashDeposit cashDeposit;
	private static CollateralCashDeposit invalidCollateralType;
	private static CollateralDetailsRequestModel requestModelRealEstate;
	private static CollateralDetailsRequestModel requestModelCashDeposit;
	private static CollateralDetailsRequestModel requestModelInvalidType;
	private static Customer customer1;
	private static Customer customer2;
	private static Loan loanProduct1;
	private static Loan loanProduct2;
	private static CustomerLoan custLoan1;
	private static CustomerLoan custLoan2;

	@BeforeAll
	static void init() {
		log.info("Initializing data...");
		ModelMapper modelMapper = new ModelMapper();
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);

		realEstate = new CollateralRealEstate();
		realEstate.setCollateralId(123);
		realEstate.setCollateralType(CollateralType.REAL_ESTATE.name());
		realEstate.setCurrentValue(1500000.0);
		realEstate.setDepreciationRate(5.0);
		realEstate.setLoanId(10001);
		realEstate.setAddress("Kolkata");
		realEstate.setOwnerName("Himashu");
		realEstate.setRatePerSqFt(5000.0);

		cashDeposit = new CollateralCashDeposit();
		cashDeposit.setCollateralId(456);
		cashDeposit.setCollateralType(CollateralType.CASH_DEPOSIT.name());
		cashDeposit.setCurrentValue(2000000.0);
		cashDeposit.setDepositAmount(800000.0);
		cashDeposit.setInterestRate(15.0);
		cashDeposit.setLoanId(10001);
		cashDeposit.setLockPeriod(10);
		cashDeposit.setAddress("Kolkata");
		cashDeposit.setOwnerName("Himashu");

		invalidCollateralType = new CollateralCashDeposit();
		invalidCollateralType.setCollateralId(999);
//		invalidCollateralType.setCollateralType(CollateralType.ANONYMOUS_COLLATERAL_TYPE.name());
		invalidCollateralType.setCurrentValue(2000000.0);
		invalidCollateralType.setDepositAmount(800000.0);
		invalidCollateralType.setInterestRate(15.0);
		invalidCollateralType.setLoanId(10003);
		invalidCollateralType.setLockPeriod(10);
		invalidCollateralType.setAddress("Kolkata");
		invalidCollateralType.setOwnerName("Himashu");

		requestModelRealEstate = modelMapper.map(realEstate, CollateralDetailsRequestModel.class);
		requestModelCashDeposit = modelMapper.map(cashDeposit, CollateralDetailsRequestModel.class);
		requestModelInvalidType = modelMapper.map(invalidCollateralType, CollateralDetailsRequestModel.class);

		customer1 = new Customer();
		customer1.setCustomerId(101);
		customer1.setName("Sampath");
		customer1.setEmailId("sampath123@gmail.com");
		customer1.setMobileNo("7780184807");
		customer1.setAddress("Vijayawada");

		customer2 = new Customer();
		customer2.setCustomerId(102);
		customer2.setName("Sricharan");
		customer2.setEmailId("sricharan123@gmail.com");
		customer2.setMobileNo("9874561231");
		customer2.setAddress("Kolkata");

		loanProduct1 = new Loan();
		loanProduct1.setLoanProductId(1001);
		loanProduct1.setLoanProductName("Home Loan");
		loanProduct1.setMaxLoanEligible(3000000.00);
		loanProduct1.setInterestRate(10.5);
		loanProduct1.setTenure(48);
		loanProduct1.setCollateralType("REAL_ESTATE");

		loanProduct2 = new Loan();
		loanProduct2.setLoanProductId(1002);
		loanProduct2.setLoanProductName("Home Loan");
		loanProduct2.setMaxLoanEligible(1100000.00);
		loanProduct2.setInterestRate(9.5);
		loanProduct2.setTenure(40);
		loanProduct2.setCollateralType("CASH_DEPOSIT");

		custLoan1 = new CustomerLoan();
		custLoan1.setLoanId(10001);
		custLoan1.setLoanProductId(1001);
		custLoan1.setCustomerId(101);
		custLoan1.setLoanPrincipal(2500000.0);
		custLoan1.setTenure(48);
		custLoan1.setInterest(10.5);
		custLoan1.setEmi(64008.0);
		custLoan1.setCollateralId(101);
		custLoan1.setLoan(loanProduct1);

		custLoan2 = new CustomerLoan();
		custLoan2.setLoanId(10002);
		custLoan2.setLoanProductId(1002);
		custLoan2.setCustomerId(102);
		custLoan2.setLoanPrincipal(900000.0);
		custLoan2.setTenure(40);
		custLoan2.setInterest(9.5);
		custLoan2.setEmi(26338.0);
		custLoan2.setCollateralId(102);
		custLoan2.setLoan(loanProduct2);
	}

	protected String mapToJson(Object obj) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.writeValueAsString(obj);
	}

	@Test
	void testGetLoanDetailsUsingLoanIdAndCustomerId() throws Exception {
		log.info("testGetLoanDetailsUsingLoanIdAndCustomerId");
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		when(service.getLoanDetails(10001, 101)).thenReturn(custLoan1);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getLoanDetails?loanId=10001&customerId=101")
				.header("Authorization", "token").accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testGetLoanDetailsUsingLoanIdAndCustomerIdWithAuthorizationException() throws Exception {
		log.info("testGetLoanDetailsUsingLoanIdAndCustomerId");
		when(authclient.authorizeTheRequest("token")).thenReturn(false);
		when(service.getLoanDetails(10001, 101)).thenReturn(custLoan1);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getLoanDetails?loanId=10001&customerId=101")
				.header("Authorization", "token").accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(401, status);
	}

	@Test
	void testGetLoanDetailsUsingInvalidLoanIdAndCustomerId() throws Exception {
		log.info("testGetLoanDetailsUsingInvalidLoanIdAndCustomerId");
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		when(service.getLoanDetails(10001, 999)).thenThrow(CustomerLoanNotFoundException.class);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getLoanDetails?loanId=10001&collateralId=999")
				.header("Authorization", "token").accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(400, status);
	}

	@Test
	void testSaveRealEstateCollateralDetails() throws Exception {
		log.info("testSaveRealEstateCollateralDetails");
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		when(service.saveCollaterals(10001, 123, CollateralType.REAL_ESTATE, requestModelRealEstate, "token"))
				.thenReturn(true);
		String requestBody = this.mapToJson(requestModelRealEstate);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/saveCollaterals/10001/123/REAL_ESTATE")
				.header("Authorization", "token").content(requestBody).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);

		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testSaveCashDepositCollateralDetails() throws Exception {
		log.info("testSaveCashDepositCollateralDetails");
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		when(service.saveCollaterals(10002, 456, CollateralType.CASH_DEPOSIT, requestModelCashDeposit, "token"))
				.thenReturn(true);
		String requestBody = this.mapToJson(requestModelCashDeposit);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/saveCollaterals/10002/456/CASH_DEPOSIT")
				.header("Authorization", "token").content(requestBody).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);

		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testSaveAnyonymousCollateralDetails() throws Exception {
		log.info("testAnyonymousCollateralDetails");
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		String requestBody = this.mapToJson(requestModelInvalidType);
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/saveCollaterals/10003/999/ANONYMOUS_COLLATERAL_TYPE").header("Authorization", "token")
				.content(requestBody).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON);

		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(400, status);
	}

	@Test
	void testGetCollateralAuthorizationException() throws Exception {
		when(authclient.authorizeTheRequest("token")).thenReturn(false);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getCollaterals?loanId=10002&collateralId=456")
				.header("Authorization", "token").accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		assertEquals(404, mvcResult.getResponse().getStatus());
	}

	@Test
	void testSaveCollateralDetailsUnauthorized() throws Exception {
		log.info("testSaveCashDepositCollateralDetails");
		when(authclient.authorizeTheRequest("token")).thenReturn(false);
		when(service.saveCollaterals(10002, 456, CollateralType.CASH_DEPOSIT, requestModelCashDeposit, "token"))
				.thenReturn(true);
		String requestBody = this.mapToJson(requestModelCashDeposit);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/saveCollaterals/10002/456/CASH_DEPOSIT")
				.header("Authorization", "token").content(requestBody).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);

		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(401, status);
	}

	@Test
	void testGetAllCustomers() throws Exception {
		log.info("testGetAllCustomers");
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		List<Customer> list = new ArrayList<>();
		list.add(customer1);
		list.add(customer2);
		when(service.getAllCustomers()).thenReturn(list);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getAllCustomers").header("Authorization", "token")
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON);

		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testGetAllLoanProducts() throws Exception {
		log.info("getAllLoanProducts");
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		List<Loan> list = new ArrayList<>();
		list.add(loanProduct1);
		list.add(loanProduct2);
		when(service.getAllProducts()).thenReturn(list);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getAllLoanProducts")
				.header("Authorization", "token").contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);

		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testGetAllCustomersUnauthorized() throws Exception {
		log.info("testGetAllCustomers");
		when(authclient.authorizeTheRequest("token")).thenReturn(false);
		List<Customer> list = new ArrayList<>();
		list.add(customer1);
		list.add(customer2);
		when(service.getAllCustomers()).thenReturn(list);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getAllCustomers").header("Authorization", "token")
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON);

		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(401, status);
	}

	@Test
	void testGetAllLoanProductsUnauthorized() throws Exception {
		log.info("getAllLoanProducts");
		when(authclient.authorizeTheRequest("token")).thenReturn(false);
		List<Loan> list = new ArrayList<>();
		list.add(loanProduct1);
		list.add(loanProduct2);
		when(service.getAllProducts()).thenReturn(list);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getAllLoanProducts")
				.header("Authorization", "token").contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);

		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(401, status);
	}

	@Test
	void testHealthCheck() throws Exception {
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/health-check").header("Authorization", "token")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mvc.perform(requestBuilder).andReturn();
		assertEquals(200, result.getResponse().getStatus());
	}

	@Test
	void testHealthCheckFailure() throws Exception {
		when(authclient.authorizeTheRequest("token")).thenReturn(false);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/health-check").header("Authorization", "token")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mvc.perform(requestBuilder).andReturn();
		assertEquals(401, result.getResponse().getStatus());
	}
}
