package com.cognizant.mfpe.portal.entity;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class JwtRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 58964751125789632L;
	
	@NotEmpty(message = "User Name must not be empty")
	@NotNull(message = "username must not be null")
	
	private String userName;
	
	@NotEmpty(message = "Password Name must not be empty")
	private String password;

}
