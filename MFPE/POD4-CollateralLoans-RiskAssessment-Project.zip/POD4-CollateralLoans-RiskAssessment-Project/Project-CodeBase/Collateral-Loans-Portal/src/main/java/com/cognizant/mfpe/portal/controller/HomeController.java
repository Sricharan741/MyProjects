package com.cognizant.mfpe.portal.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.cognizant.mfpe.portal.exception.AuthorizationException;
import com.cognizant.mfpe.portal.feign.AuthorizationClient;
import com.cognizant.mfpe.portal.feign.LoanFeignClient;
import com.cognizant.mfpe.portal.pojo.Loan;

import feign.FeignException;

@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);


	private AuthorizationClient authorizationClient;

	private LoanFeignClient loanFeignClient;
	
	private final String message = "Authorization Failed";

	@Autowired
	public HomeController(LoanFeignClient loanFeignClient, AuthorizationClient authorizationClient) {
		super();
		this.authorizationClient = authorizationClient;
		this.loanFeignClient = loanFeignClient;
	}

	@GetMapping("/home")
	public String home(HttpServletRequest request, Model model) throws AuthorizationException {
		logger.info("Inside home controller");
		if (!isAuthorized(request)) {
			logger.warn(message);
			throw new AuthorizationException(message);
		}
		List<Loan> loanProducts = loanFeignClient
				.getAllLoanProducts((String) request.getSession().getAttribute("Authorization")).getBody();
		model.addAttribute("loanProductList", loanProducts);
		return "home";
	}

	private boolean isAuthorized(HttpServletRequest request) throws AuthorizationException {
		logger.info("Inside authorization request checking method");
		try {
			return authorizationClient.authorizeTheRequest((String) request.getSession().getAttribute("Authorization"));
		} catch (FeignException ex) {
			logger.warn(message);
			throw new AuthorizationException(message);
		}
	}
}
