package com.cognizant.mfpe.portal.exception;

@SuppressWarnings("serial")
public class FeignClientException extends Exception {

	public FeignClientException(String message) {
		super(message);
	}

}
