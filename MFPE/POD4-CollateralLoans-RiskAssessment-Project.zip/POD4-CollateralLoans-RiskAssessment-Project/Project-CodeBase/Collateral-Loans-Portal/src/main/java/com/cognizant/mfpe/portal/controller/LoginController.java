package com.cognizant.mfpe.portal.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.cognizant.mfpe.portal.entity.JwtRequest;
import com.cognizant.mfpe.portal.feign.AuthorizationClient;

import lombok.extern.slf4j.Slf4j;

@Controller
@SessionAttributes("userName")
@Slf4j
public class LoginController {

	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

	@Autowired
	private AuthorizationClient client;

	@GetMapping("/login")
	public String login(@ModelAttribute("user") JwtRequest user) {
		return "login";
	}

	@PostMapping("/login")
	public String checkLogin(@Valid @ModelAttribute("user") JwtRequest user, BindingResult result, Model model,
			HttpServletRequest request) {

		if (result.hasErrors()) {
			return "login";
		} else {
			ResponseEntity<?> response = null;
			try {

				response = client.createAuthenticationToken(user);
				logger.info("Generating authentication token by authenticating the user");
			} catch (Exception e) {
				logger.warn(e.getMessage());
				logger.info(e.getMessage() + "=========================");
				e.printStackTrace();
				model.addAttribute("errorMessage", "Invalid Credentials");
				return "login";
			}
			@SuppressWarnings("unchecked")
			Map<String, String> tokenMap = (Map<String, String>) response.getBody();
			String token = tokenMap.get("token");
			log.info("Bearer " + token);
			log.info("userName:" + user.getUserName());

			request.getSession().setAttribute("Authorization", "Bearer " + token);
			request.getSession().setAttribute("userName", user.getUserName());
			return "redirect:/home";
		}
	}

	/**
	 * @param model
	 * @param request
	 * @return
	 */
	@GetMapping(value = "/logout")
	public String logoutAndShowLoginPage(Model model, HttpServletRequest request, HttpServletResponse response) {
		/*
		 * set session as invalidate set username to null
		 */
		logger.info("Inside logout method");
		request.getSession().invalidate();
		model.addAttribute("userName", null);
		logger.info("Session Destroyed");
		return "redirect:/login";
	}
}
