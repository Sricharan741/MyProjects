package com.cognizant.mfpe.portal.pojo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class CollateralMarketValue {

	private Integer sNo;

	private Integer loanId;

	private Integer customerId;

	private String collateralType;

	private Double marketValue;

}