package com.cognizant.mfpe.collateral.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cognizant.mfpe.collateral.entities.Collateral;
import com.cognizant.mfpe.collateral.entities.CollateralCashDeposit;
import com.cognizant.mfpe.collateral.entities.CollateralLoan;
import com.cognizant.mfpe.collateral.entities.CollateralRealEstate;
import com.cognizant.mfpe.collateral.entities.CollateralType;
import com.cognizant.mfpe.collateral.exception.CollateralLoanNotFoundException;
import com.cognizant.mfpe.collateral.repository.CashDepositRepository;
import com.cognizant.mfpe.collateral.repository.CollateralLoanRepository;
import com.cognizant.mfpe.collateral.repository.RealEstateRepository;
import com.cognizant.mfpe.collateral.ui.CollateralDetailsRequestModel;

import lombok.extern.slf4j.Slf4j;

/**
 * Test - CollateralServiceTest class
 */
@SpringBootTest
@RunWith(SpringRunner.class)
@Slf4j
class CollateralServiceTest {

	@MockBean
	private CollateralLoanRepository collateralLoanRepository;

	@MockBean
	private RealEstateRepository realEstateRepository;

	@MockBean
	private CashDepositRepository cashDepositRepository;

	@InjectMocks
	@Autowired
	private CollateralServiceImpl service;

	private static CollateralRealEstate realEstate;
	private static CollateralCashDeposit cashDeposit;
	private static CollateralCashDeposit invalidCollateralType;
	private static CollateralLoan collateralLoanRealEstate;
	private static CollateralLoan collateralLoanCashDeposit;
	private static CollateralDetailsRequestModel requestModelRealEstate;
	private static CollateralDetailsRequestModel requestModelCashDeposit;

	@BeforeAll
	static void init() {
		log.info("Initializing data...");
		ModelMapper modelMapper = new ModelMapper();
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);

		realEstate = new CollateralRealEstate();
		realEstate.setCollateralId(123);
		realEstate.setCollateralType(CollateralType.REAL_ESTATE.name());
		realEstate.setCurrentValue(1500000.0);
		realEstate.setDepreciationRate(5.0);
		realEstate.setLoanId(10001);
		realEstate.setAddress("Kolkata");
		realEstate.setOwnerName("Himashu");
		realEstate.setRatePerSqFt(5000.0);

		cashDeposit = new CollateralCashDeposit();
		cashDeposit.setCollateralId(456);
		cashDeposit.setCollateralType(CollateralType.CASH_DEPOSIT.name());
		cashDeposit.setCurrentValue(2000000.0);
		cashDeposit.setDepositAmount(800000.0);
		cashDeposit.setInterestRate(15.0);
		cashDeposit.setLoanId(10001);
		cashDeposit.setLockPeriod(10);
		cashDeposit.setAddress("Kolkata");
		cashDeposit.setOwnerName("Himashu");

		invalidCollateralType = new CollateralCashDeposit();
		invalidCollateralType.setCollateralId(999);
		invalidCollateralType.setCurrentValue(2000000.0);
		invalidCollateralType.setDepositAmount(800000.0);
		invalidCollateralType.setInterestRate(15.0);
		invalidCollateralType.setLoanId(10003);
		invalidCollateralType.setLockPeriod(10);
		invalidCollateralType.setAddress("Kolkata");
		invalidCollateralType.setOwnerName("Himashu");

		collateralLoanCashDeposit = new CollateralLoan();
		collateralLoanCashDeposit.setCollateralId(456);
		collateralLoanCashDeposit.setLoanId(10002);
		collateralLoanCashDeposit.setCollateralValue(2000000.0);
		collateralLoanCashDeposit.setCollateral(modelMapper.map(cashDeposit, Collateral.class));
		collateralLoanCashDeposit.setPledgedDate(LocalDate.now());

		collateralLoanRealEstate = new CollateralLoan();
		collateralLoanRealEstate.setCollateralId(123);
		collateralLoanRealEstate.setLoanId(10001);
		collateralLoanRealEstate.setCollateralValue(1500000.0);
		collateralLoanRealEstate.setCollateral(modelMapper.map(realEstate, Collateral.class));
		collateralLoanRealEstate.setPledgedDate(LocalDate.now());

		requestModelRealEstate = modelMapper.map(realEstate, CollateralDetailsRequestModel.class);
		requestModelCashDeposit = modelMapper.map(cashDeposit, CollateralDetailsRequestModel.class);

	}

	@Test
	void testGetRealEstateCollateralLoanUsingLoanIdAndCollateralId() throws Exception {
		realEstateRepository.save(realEstate);
		collateralLoanRepository.save(collateralLoanRealEstate);
		when(collateralLoanRepository.findByLoanIdAndCollateralId(10001, 123)).thenReturn(collateralLoanRealEstate);
		assertThat(service.getCollaterals(10001, 123)).isEqualTo(collateralLoanRealEstate);
	}

	@Test
	void testGetCashDepositCollateralLoanUsingLoanIdAndCollateralId() throws Exception {
		cashDepositRepository.save(cashDeposit);
		collateralLoanRepository.save(collateralLoanCashDeposit);
		when(collateralLoanRepository.findByLoanIdAndCollateralId(10002, 456)).thenReturn(collateralLoanCashDeposit);
		assertThat(service.getCollaterals(10002, 456)).isEqualTo(collateralLoanCashDeposit);
	}

	@Test
	void testGetLoanNotFoundExceptionForCollateralLoanUsingLoanIdAndCollateralId() throws Exception {
		when(collateralLoanRepository.findByLoanIdAndCollateralId(10003, 999)).thenReturn(null);
		assertThrows(CollateralLoanNotFoundException.class, () -> service.getCollaterals(10003, 999));
	}

	@Test
	void testSaveRealEstateCollateralDetails() throws Exception {
		log.info("testSaveRealEstateCollateralDetails");
		assertTrue(service.saveCollaterals(10001, 123, CollateralType.REAL_ESTATE, requestModelRealEstate));
	}

	@Test
	void testSaveCashDepositCollateralDetails() throws Exception {
		log.info("testSaveCashDepositCollateralDetails");
		assertTrue(service.saveCollaterals(10002, 456, CollateralType.CASH_DEPOSIT, requestModelCashDeposit));
	}

}
