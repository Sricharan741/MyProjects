package com.cognizant.mfpe.collateral.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.cognizant.mfpe.collateral.entities.Collateral;
import com.cognizant.mfpe.collateral.entities.CollateralCashDeposit;
import com.cognizant.mfpe.collateral.entities.CollateralLoan;
import com.cognizant.mfpe.collateral.entities.CollateralRealEstate;
import com.cognizant.mfpe.collateral.entities.CollateralType;
import com.cognizant.mfpe.collateral.exception.CollateralLoanNotFoundException;
import com.cognizant.mfpe.collateral.feign.AuthorizationClient;
import com.cognizant.mfpe.collateral.service.CollateralService;
import com.cognizant.mfpe.collateral.ui.CollateralDetailsRequestModel;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * Test - CollateralRestController class
 */
@RunWith(SpringRunner.class)
@WebMvcTest(CollateralRestController.class)
@Slf4j
class CollateralControllerTests {

	@Autowired
	private MockMvc mvc;

	@MockBean
	private CollateralService service;

	@MockBean
	private AuthorizationClient authclient;

	private static CollateralRealEstate realEstate;
	private static CollateralCashDeposit cashDeposit;
	private static CollateralCashDeposit invalidCollateralType;
	private static CollateralLoan collateralLoanRealEstate;
	private static CollateralLoan collateralLoanCashDeposit;
	private static CollateralDetailsRequestModel requestModelRealEstate;
	private static CollateralDetailsRequestModel requestModelCashDeposit;
	private static CollateralDetailsRequestModel requestModelInvalidType;

	@BeforeAll
	static void init() {
		log.info("Initializing data...");
		ModelMapper modelMapper = new ModelMapper();
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);

		realEstate = new CollateralRealEstate();
		realEstate.setCollateralId(123);
		realEstate.setCollateralType(CollateralType.REAL_ESTATE.name());
		realEstate.setCurrentValue(1500000.0);
		realEstate.setDepreciationRate(5.0);
		realEstate.setLoanId(10001);
		realEstate.setAddress("Kolkata");
		realEstate.setOwnerName("Himashu");
		realEstate.setRatePerSqFt(5000.0);

		cashDeposit = new CollateralCashDeposit();
		cashDeposit.setCollateralId(456);
		cashDeposit.setCollateralType(CollateralType.CASH_DEPOSIT.name());
		cashDeposit.setCurrentValue(2000000.0);
		cashDeposit.setDepositAmount(800000.0);
		cashDeposit.setInterestRate(15.0);
		cashDeposit.setLoanId(10001);
		cashDeposit.setLockPeriod(10);
		cashDeposit.setAddress("Kolkata");
		cashDeposit.setOwnerName("Himashu");

		invalidCollateralType = new CollateralCashDeposit();
		invalidCollateralType.setCollateralId(999);
		invalidCollateralType.setCurrentValue(2000000.0);
		invalidCollateralType.setDepositAmount(800000.0);
		invalidCollateralType.setInterestRate(15.0);
		invalidCollateralType.setLoanId(10003);
		invalidCollateralType.setLockPeriod(10);
		invalidCollateralType.setAddress("Kolkata");
		invalidCollateralType.setOwnerName("Himashu");

		collateralLoanCashDeposit = new CollateralLoan();
		collateralLoanCashDeposit.setCollateralId(456);
		collateralLoanCashDeposit.setLoanId(10002);
		collateralLoanCashDeposit.setCollateralValue(2000000.0);
		collateralLoanCashDeposit.setCollateral(modelMapper.map(cashDeposit, Collateral.class));
		collateralLoanCashDeposit.setPledgedDate(LocalDate.now());

		collateralLoanRealEstate = new CollateralLoan();
		collateralLoanRealEstate.setCollateralId(123);
		collateralLoanRealEstate.setLoanId(10001);
		collateralLoanRealEstate.setCollateralValue(1500000.0);
		collateralLoanRealEstate.setCollateral(modelMapper.map(realEstate, Collateral.class));
		collateralLoanRealEstate.setPledgedDate(LocalDate.now());

		requestModelRealEstate = modelMapper.map(realEstate, CollateralDetailsRequestModel.class);
		requestModelCashDeposit = modelMapper.map(cashDeposit, CollateralDetailsRequestModel.class);
		requestModelInvalidType = modelMapper.map(invalidCollateralType, CollateralDetailsRequestModel.class);

	}

	protected String mapToJson(Object obj) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.writeValueAsString(obj);
	}

	@Test
	void testGetRealEstateCollateralLoanWithLoanIdAndCollateralId() throws Exception {
		log.info("testGetRealEstateCollateralLoanWithLoanIdAndCollateralId");
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		when(service.getCollaterals(10001, 123)).thenReturn(collateralLoanRealEstate);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getCollaterals?loanId=10001&collateralId=123")
				.header("Authorization", "token").accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testGetCashDepositCollateralLoanWithLoanIdAndCollateralId() throws Exception {
		log.info("testGetCashDepositCollateralLoanWithLoanIdAndCollateralId");
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		when(service.getCollaterals(10002, 456)).thenReturn(collateralLoanCashDeposit);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getCollaterals?loanId=10002&collateralId=456")
				.header("Authorization", "token").accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testGetCollateralLoanWithInvalidLoanIdAndCollateralId() throws Exception {
		log.info("testGetCollateralLoanWithInvalidLoanIdAndCollateralId");
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		when(service.getCollaterals(10003, 999)).thenThrow(CollateralLoanNotFoundException.class);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getCollaterals?loanId=10003&collateralId=999")
				.header("Authorization", "token").accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(400, status);
	}

	@Test
	void testSaveRealEstateCollateralDetails() throws Exception {
		log.info("testSaveRealEstateCollateralDetails");
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		when(service.saveCollaterals(10001, 123, CollateralType.REAL_ESTATE, requestModelRealEstate)).thenReturn(true);
		String requestBody = this.mapToJson(requestModelRealEstate);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/saveCollaterals/10001/123/REAL_ESTATE")
				.header("Authorization", "token").content(requestBody).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);

		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testSaveCashDepositCollateralDetails() throws Exception {
		log.info("testSaveCashDepositCollateralDetails");
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		when(service.saveCollaterals(10002, 456, CollateralType.CASH_DEPOSIT, requestModelCashDeposit))
				.thenReturn(true);
		String requestBody = this.mapToJson(requestModelCashDeposit);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/saveCollaterals/10002/456/CASH_DEPOSIT")
				.header("Authorization", "token").content(requestBody).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);

		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testSaveAnyonymousCollateralDetails() throws Exception {
		log.info("testAnyonymousCollateralDetails");
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		String requestBody = this.mapToJson(requestModelInvalidType);
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/saveCollaterals/10003/999/ANONYMOUS_COLLATERAL_TYPE").header("Authorization", "token")
				.content(requestBody).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON);

		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(400, status);
	}

	@Test
	void testGetCollateralAuthorizationException() throws Exception {
		when(authclient.authorizeTheRequest("token")).thenReturn(false);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getCollaterals?loanId=10002&collateralId=456")
				.header("Authorization", "token").accept(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();
		assertEquals(401, mvcResult.getResponse().getStatus());
	}

	@Test
	void testSaveCollateralDetailsAuthorizationException() throws Exception {
		when(authclient.authorizeTheRequest("token")).thenReturn(false);
		String requestBody = this.mapToJson(requestModelCashDeposit);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/saveCollaterals/10002/456/CASH_DEPOSIT")
				.header("Authorization", "token").content(requestBody).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);

		MvcResult mvcResult = mvc.perform(requestBuilder).andReturn();

		assertEquals(401, mvcResult.getResponse().getStatus());
	}

	@Test
	void testHealthCheck() throws Exception {
		when(authclient.authorizeTheRequest("token")).thenReturn(true);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/health-check").header("Authorization", "token")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mvc.perform(requestBuilder).andReturn();
		assertEquals(200, result.getResponse().getStatus());
	}

	@Test
	void testHealthCheckFailure() throws Exception {
		when(authclient.authorizeTheRequest("token")).thenReturn(false);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/health-check").header("Authorization", "token")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mvc.perform(requestBuilder).andReturn();
		assertEquals(401, result.getResponse().getStatus());
	}
}
