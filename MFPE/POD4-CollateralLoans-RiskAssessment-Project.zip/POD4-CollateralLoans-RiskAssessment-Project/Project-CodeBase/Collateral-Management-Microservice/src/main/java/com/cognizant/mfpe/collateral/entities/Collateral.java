package com.cognizant.mfpe.collateral.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ApiModel(description = "Details of Entity Collateral")
@Entity
@NoArgsConstructor
@Getter
@Setter
@Inheritance(strategy = InheritanceType.JOINED)
public class Collateral {

	@ApiModelProperty(notes = "CollateralId of Entity Collateral", name = "collateralId", dataType = "Integer")
	@Id
	private Integer collateralId;

	@ApiModelProperty(notes = "LoanId of Entity Collaterl", name = "loanId", dataType = "Integer")
	private Integer loanId;

	@ApiModelProperty(notes = "CollateralType Of Collateral which may be REAL_ESTATE,CASH_DEPOSITetc.", name = "collateralType", dataType = "String")
	private String collateralType;

	@ApiModelProperty(notes = "Name of Person Who took the Collateral Loan", name = "ownername", dataType = "String")
	private String ownerName;

	@ApiModelProperty(notes = "Address of Person", name = "address", dataType = "String")
	private String address;

	@ApiModelProperty(notes = "CurrentValue of Collateral", name = "currentValue", dataType = "Double")
	private Double currentValue;

}
