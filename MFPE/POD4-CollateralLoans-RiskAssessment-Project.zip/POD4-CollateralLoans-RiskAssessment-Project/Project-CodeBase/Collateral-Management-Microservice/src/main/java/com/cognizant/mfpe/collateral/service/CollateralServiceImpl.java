package com.cognizant.mfpe.collateral.service;

import java.time.LocalDate;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.cognizant.mfpe.collateral.entities.CollateralCashDeposit;
import com.cognizant.mfpe.collateral.entities.CollateralLoan;
import com.cognizant.mfpe.collateral.entities.CollateralRealEstate;
import com.cognizant.mfpe.collateral.entities.CollateralType;
import com.cognizant.mfpe.collateral.exception.CollateralLoanNotFoundException;
import com.cognizant.mfpe.collateral.repository.CashDepositRepository;
import com.cognizant.mfpe.collateral.repository.CollateralLoanRepository;
import com.cognizant.mfpe.collateral.repository.RealEstateRepository;
import com.cognizant.mfpe.collateral.ui.CollateralDetailsRequestModel;

@Service
public class CollateralServiceImpl implements CollateralService {

	private static final Logger logger = LoggerFactory.getLogger(CollateralServiceImpl.class);

	private CollateralLoanRepository collateralLoanRepository;

	private RealEstateRepository realEstateRepository;

	private CashDepositRepository cashDepositRepository;

	private ModelMapper modelMapper;

	@Autowired
	public CollateralServiceImpl(CollateralLoanRepository collateralLoanRepository,
			RealEstateRepository realEstateRepository, CashDepositRepository cashDepositRepository,
			ModelMapper modelMapper) {
		super();
		this.collateralLoanRepository = collateralLoanRepository;
		this.realEstateRepository = realEstateRepository;
		this.cashDepositRepository = cashDepositRepository;
		this.modelMapper = modelMapper;
	}

	@Override
	public CollateralLoan getCollaterals(Integer loanId, Integer collateralId) throws CollateralLoanNotFoundException {
		// Check if collateral loan has an entry or not
		logger.info("Inside Get collaterals method");
		CollateralLoan collateralLoan = collateralLoanRepository.findByLoanIdAndCollateralId(loanId, collateralId);
		if (collateralLoan == null) {
			logger.warn("Collateral Details not found for particular Loan id");
			throw new CollateralLoanNotFoundException("Collateral Details not found for LoanId: " + loanId);
		}
		logger.debug("Collateral Loan Details" + collateralLoan);
		return collateralLoan;
	}

	@Override
	public Boolean saveCollaterals(Integer loanId, Integer collateralId, CollateralType collateralType,
			CollateralDetailsRequestModel requestModel) throws MethodArgumentTypeMismatchException {
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		// Map collateral to respective collateralType and save it
		logger.info("Inside Save Collaterals method");
		logger.info("Checking collateral type Rea estate or not");
		if (collateralType.equals(CollateralType.REAL_ESTATE)) {
			
			logger.info("Type = REAL_ESTATE");
			CollateralRealEstate collateralRealEstate = modelMapper.map(requestModel, CollateralRealEstate.class);

			this.saveCollateralRealEstate(loanId, collateralId, collateralRealEstate);

			this.saveCollateralLoan(
					new CollateralLoan(loanId, collateralId, requestModel.getCollateralValue(), LocalDate.now()));
			logger.info("Collatera Detais  of type real estate details are Saved");
			return true;
		}
		else if (collateralType.equals(CollateralType.CASH_DEPOSIT)) {
			
			logger.info("Type = CASH_DEPOSIT");
			CollateralCashDeposit collateralCashDeposit = modelMapper.map(requestModel, CollateralCashDeposit.class);

			this.saveCollateralCashDeposit(loanId, collateralId, collateralCashDeposit);

			this.saveCollateralLoan(
					new CollateralLoan(loanId, collateralId, requestModel.getCollateralValue(), LocalDate.now()));
			logger.info("Collatera Detais  of type cash deposit details are Saved");
			return true;
		} else {
			logger.info("Collateral type doesnot exist");
			return false;
		}

	}

	private void saveCollateralLoan(CollateralLoan collateralLoan) {
		logger.info("Inside save Collateral Loan method");
		logger.info("collatera Loan detais saved");
		collateralLoanRepository.save(collateralLoan);
	}

	private void saveCollateralRealEstate(Integer loanId, Integer collateralId,
			CollateralRealEstate collateralRealEstate) {
		logger.info("Inside save Collateral Real estate method");
	
		// Set loanId, collateralId, collateralType for collateralRealEstate
		collateralRealEstate.setLoanId(loanId);
		collateralRealEstate.setCollateralId(collateralId);
		collateralRealEstate.setCollateralType("REAL_ESTATE");
		logger.info("collatera real estate detais saved");
		realEstateRepository.save(collateralRealEstate);
	}

	private void saveCollateralCashDeposit(Integer loanId, Integer collateralId,
			CollateralCashDeposit collateralCashDeposit) {
		logger.info("Inside save Collateral cash deposit method");
		
		// Set loanId, collateralId, collateralType for collateralCashDeposit
		collateralCashDeposit.setLoanId(loanId);
		collateralCashDeposit.setCollateralId(collateralId);
		collateralCashDeposit.setCollateralType("CASH_DEPOSIT");
		logger.info("collatera cash deposit detais saved");
		cashDepositRepository.save(collateralCashDeposit);
	}

}
