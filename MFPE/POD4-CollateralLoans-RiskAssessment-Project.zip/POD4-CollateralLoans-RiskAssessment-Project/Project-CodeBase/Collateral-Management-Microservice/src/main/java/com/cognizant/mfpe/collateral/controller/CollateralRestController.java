package com.cognizant.mfpe.collateral.controller;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.cognizant.mfpe.collateral.entities.CollateralLoan;
import com.cognizant.mfpe.collateral.entities.CollateralType;
import com.cognizant.mfpe.collateral.exception.AuthorizationException;
import com.cognizant.mfpe.collateral.exception.CollateralTypeNotFoundException;
import com.cognizant.mfpe.collateral.feign.AuthorizationClient;
import com.cognizant.mfpe.collateral.service.CollateralService;
import com.cognizant.mfpe.collateral.ui.CollateralDetailsRequestModel;
import com.cognizant.mfpe.collateral.ui.CollateralDetailsResponseModel;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
public class CollateralRestController {

	private static final Logger logger = LoggerFactory.getLogger(CollateralRestController.class);

	private CollateralService service;

	private Environment environment;

	private AuthorizationClient authorizationClient;

	@Autowired
	public CollateralRestController(CollateralService service, Environment environment,
			AuthorizationClient authorizationClient) {
		super();
		this.service = service;
		this.environment = environment;
		this.authorizationClient = authorizationClient;
	}

	@ApiOperation(value = "health-check", notes = "This method retrieves the port value")
	@ApiResponse(code = 401, message = "UnAuthorized Error")
	@GetMapping("/health-check")
	public ResponseEntity<?> healthCheck(
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader)
			throws AuthorizationException {
		logger.info("Inside HealthCheck Controller");
		logger.info("Token Checking");
		if (authorizationClient.authorizeTheRequest(requestTokenHeader)) {
			logger.info("Token Authorized ");
			logger.info("Port running on " + environment.getProperty("local.server.port"));
			return ResponseEntity.ok("Running on port :" + environment.getProperty("local.server.port"));
		} else {
			logger.warn("Token Not Authorized");
			throw new AuthorizationException("Not allowed");
		}
	}

	@ApiOperation(value = "saveCollaterals", notes = "This method stores the collateral details")
	@ApiResponses(value = { @ApiResponse(code = 401, message = "Unauthorized Error"),
			@ApiResponse(code = 404, message = "Collateral Type Not Found Exception") })
	@PostMapping("/saveCollaterals/{loanId}/{collateralId}/{collateralType}")
	public ResponseEntity<Boolean> saveCollaterals(
			@ApiParam(value = "LoanId", name = "loanId", type = "Integer", example = "10", required = true) @PathVariable Integer loanId,
			@ApiParam(value = "CollateralId", name = "collateralId", type = "Integer", example = "2", required = true) @PathVariable Integer collateralId,
			@ApiParam(value = "LoanType", name = "collateralType", type = "CollateralType", example = "REAL_ESTATE", required = true) @PathVariable CollateralType collateralType,
			@RequestBody CollateralDetailsRequestModel requestModel,
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws Exception {
		logger.info("Inside Save Collaterals Controller");
		if (authorizationClient.authorizeTheRequest(requestTokenHeader)) {
			logger.info("Token Authorized");
			try {
				logger.info("Collateral Details are saved ");
				return ResponseEntity.ok(service.saveCollaterals(loanId, collateralId, collateralType, requestModel));
			} catch (MethodArgumentTypeMismatchException ex) {
				logger.warn("Colateral Type Not Found");
				throw new CollateralTypeNotFoundException("Collateral Type not found for LoanId: " + loanId);
			}
		} else {
			logger.warn("Token Not Authorized");
			throw new AuthorizationException("Not allowed");
		}

	}

	@ApiOperation(value = "getCollaterals", notes = "This method retrieves Collateral Details by LoanId", response = CollateralDetailsResponseModel.class)
	@ApiResponses(value = { @ApiResponse(code = 401, message = "Unauthorized Error"),
			@ApiResponse(code = 404, message = "Collateral Loan Not Found") })
	@GetMapping("/getCollaterals")
	public ResponseEntity<CollateralDetailsResponseModel> getCollaterals(
			@ApiParam(value = "LoanId Of Collateral", name = "loanId", type = "Integer", example = "10", required = true) @RequestParam Integer loanId,
			@ApiParam(value = "collateralId Of Collateral", name = "collateralId", type = "Integer", example = "10", required = true) @RequestParam Integer collateralId,
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws Exception {
		logger.info("Inside Get Collaterals Controller");
		logger.info("Token checking");
		if (authorizationClient.authorizeTheRequest(requestTokenHeader)) {
			logger.info("Token Authorized");
			CollateralLoan collateralLoan = service.getCollaterals(loanId, collateralId);

			// Generating response model
			Map<String, Object> details = new LinkedHashMap<>();
			details.put("loanId", collateralLoan.getLoanId());
			details.put("collateralType", collateralLoan.getCollateral().getCollateralType());
			details.put("details", collateralLoan.getCollateral());
			logger.info("Collateral Details are taken from db ");
			return ResponseEntity.ok(new CollateralDetailsResponseModel(details));
		} else {
			logger.warn("Token Not Authorized");
			throw new AuthorizationException("Not allowed");
		}

	}

}
