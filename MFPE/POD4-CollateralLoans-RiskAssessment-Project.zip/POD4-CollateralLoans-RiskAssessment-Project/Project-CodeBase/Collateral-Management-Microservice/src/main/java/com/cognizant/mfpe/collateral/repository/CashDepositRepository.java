package com.cognizant.mfpe.collateral.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.mfpe.collateral.entities.CollateralCashDeposit;

@Repository
public interface CashDepositRepository extends JpaRepository<CollateralCashDeposit, Integer> {

}
