package com.cognizant.mfpe.collateral.entities;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ApiModel(description = "Details Of Collateral Loan")
@Entity
@NoArgsConstructor
@Getter
@Setter
public class CollateralLoan {

	@ApiModelProperty(notes = "LoanId of Collateral Loan", name = "loanId", dataType = "Integer")
	@Id
	
	private Integer loanId; // This is loan id
	@ApiModelProperty(notes = "CollateralId of Collateral Loan", name = "collateralId", dataType = "Integer")
	private Integer collateralId;
	@ApiModelProperty(notes = "Collateral value refers to the fair market value of the asset used to secure the loan", name = "collateralValue", dataType = "Double")
	private Double collateralValue;
	@ApiModelProperty(notes = "Issued Date Of Collateral Loan", name = "plegedDate", dataType = "LocalDate")
	@JsonFormat(shape = Shape.STRING, pattern = "dd-MM-yyyy")
	private LocalDate pledgedDate;

	public CollateralLoan(Integer loanId, Integer collateralId, Double collateralValue, LocalDate pledgedDate) {
		super();
		this.loanId = loanId;
		this.collateralId = collateralId;
		this.collateralValue = collateralValue;
		this.pledgedDate = pledgedDate;
	}

	@ApiModelProperty(notes = "CollateralId references to collateralId of Model Collateral", name = "collateral", dataType = "Collateral")
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "collateralId", referencedColumnName = "collateralId", insertable = false, updatable = false)
	private Collateral collateral;

}
