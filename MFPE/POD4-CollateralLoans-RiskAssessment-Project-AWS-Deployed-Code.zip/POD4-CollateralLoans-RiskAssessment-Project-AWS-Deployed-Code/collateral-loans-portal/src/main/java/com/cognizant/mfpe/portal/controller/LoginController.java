package com.cognizant.mfpe.portal.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.cognizant.mfpe.portal.entity.JwtRequest;
import com.cognizant.mfpe.portal.feign.AuthorizationClient;

import lombok.extern.slf4j.Slf4j;

@Controller
@SessionAttributes("userName")
@Slf4j
public class LoginController {

	@Autowired
	private AuthorizationClient client;

	@GetMapping("/login")
	public String login(@ModelAttribute("user") JwtRequest user) {
		return "login";
	}

	@PostMapping("/login")
	public String checkLogin(@ModelAttribute("user") JwtRequest user, Model model, HttpServletRequest request) {

		ResponseEntity<?> response = null;
		try {
			response = client.createAuthenticationToken(user);
		} catch (Exception e) {
			System.out.println(e.getMessage() + "=========================");
			e.printStackTrace();
			model.addAttribute("errorMessage", "Invalid Credentials");
			return "login";
		}
		@SuppressWarnings("unchecked")
		Map<String, String> tokenMap = (Map<String, String>) response.getBody();
		String token = tokenMap.get("token");
		log.info("Bearer " + token);
		log.info("userName:" + user.getUserName());

		request.getSession().setAttribute("Authorization", "Bearer " + token);
		request.getSession().setAttribute("userName", user.getUserName());
		return "redirect:/home";
	}

	/**
	 * @param model
	 * @param request
	 * @return
	 */
	@GetMapping(value = "/logout")
	public String logoutAndShowLoginPage(Model model, HttpServletRequest request,HttpServletResponse response) {
		/*
		 * set session as invalidate set username to null
		 */
		request.getSession().invalidate();
		model.addAttribute("userName", null);
		return "redirect:/login";
	}
}
