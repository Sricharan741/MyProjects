package com.cognizant.mfpe.portal.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cognizant.mfpe.portal.exception.AuthorizationException;
import com.cognizant.mfpe.portal.feign.AuthorizationClient;
import com.cognizant.mfpe.portal.feign.RiskFeignClient;
import com.cognizant.mfpe.portal.model.FormInputsGetRiskDetails;
import com.cognizant.mfpe.portal.pojo.CollateralMarketValue;
import com.cognizant.mfpe.portal.pojo.CollateralRisk;

import feign.FeignException;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class RiskController {

	private RiskFeignClient riskFeignClient;

	private AuthorizationClient authorizationClient;
	
	private final String message = "Authorization Failed";
	@Autowired
	public RiskController(RiskFeignClient riskFeignClient, AuthorizationClient authorizationClient) {
		super();
		this.riskFeignClient = riskFeignClient;
		this.authorizationClient = authorizationClient;
	}

	@GetMapping("/getRiskDetailsForm")
	public String getRiskDetailsForm(
			@ModelAttribute("formInputsGetRiskDetails") FormInputsGetRiskDetails formInputsGetRiskDetails,
			@ModelAttribute("error") String error, Model model, HttpServletRequest request)
			throws AuthorizationException {
		// check for authorization
		if (!isAuthorized(request)) {
			throw new AuthorizationException(message);
		}
		model.addAttribute("formInputsGetRiskDetails", formInputsGetRiskDetails);
		model.addAttribute("error", error);
		return "risk-details-form";
	}

	@PostMapping("/getCollateralRisk")
	public ModelAndView getCollaterals(
			@ModelAttribute("formInputsGetRiskDetails") FormInputsGetRiskDetails formInputsGetRiskDetails,
			BindingResult result, HttpServletRequest request, RedirectAttributes redirect, ModelAndView riskDetailsPage)
			throws AuthorizationException, Exception {
		// check for authorization
		if (!isAuthorized(request)) {
			throw new AuthorizationException(message);
		}
		if (result.hasErrors()) {
			return this.redirectToGetRiskDetailsForm(redirect, "Invalid Input", formInputsGetRiskDetails);
		}
		try {
			CollateralRisk collateralRisk = riskFeignClient.getCollateralRisk(formInputsGetRiskDetails.getLoanId(),
					(String) request.getSession().getAttribute("Authorization")).getBody();
			riskDetailsPage.setViewName("risk-details-form");
			riskDetailsPage.addObject("formInputsGetRiskDetails", formInputsGetRiskDetails);
			riskDetailsPage.addObject("status", 1);
			riskDetailsPage.addObject("collateralRisk", collateralRisk);
			return riskDetailsPage;
		} catch (FeignException ex) {
			log.info(ex.contentUTF8());
			if (!ex.contentUTF8().startsWith("{")) {
				throw new Exception(ex.getLocalizedMessage());
			}
			JSONObject json = new JSONObject(ex.contentUTF8());
			return this.redirectToGetRiskDetailsForm(redirect, json.getString("localizedMessage"), formInputsGetRiskDetails);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

	}

	@GetMapping(value = "/getMarketValues")
	public ModelAndView getAllMarketValues(HttpServletRequest request) throws AuthorizationException {
		log.info((String) request.getSession().getAttribute("Authorization"));
		if (!isAuthorized(request)) {
			throw new AuthorizationException(message);
		}
		List<CollateralMarketValue> updatedValue = new ArrayList<CollateralMarketValue>();
		updatedValue = riskFeignClient
				.getCollateralMarketValues((String) request.getSession().getAttribute("Authorization")).getBody();
//		System.out.println("id="+updatedValue.get(1));

		ModelAndView model = new ModelAndView("market-values-table");
		model.addObject("marketValue", updatedValue);
		return model;

	}

	private boolean isAuthorized(HttpServletRequest request) throws AuthorizationException {
		try {
			return authorizationClient.authorizeTheRequest((String) request.getSession().getAttribute("Authorization"));
		} catch (FeignException ex) {
			throw new AuthorizationException(message);
		}
	}

	private ModelAndView redirectToGetRiskDetailsForm(RedirectAttributes redirect, String error,
			FormInputsGetRiskDetails formInputsGetRiskDetails) {
		redirect.addFlashAttribute("error", error);
		redirect.addFlashAttribute("formInputsGetRiskDetails", formInputsGetRiskDetails);
		return new ModelAndView("redirect:/getRiskDetailsForm");
	}

}
