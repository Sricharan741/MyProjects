package com.cognizant.mfpe.portal.pojo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Loan {

	private Integer loanProductId;
	private String loanProductName;
	private Double maxLoanEligible;
	private Double interestRate;
	private Integer tenure;
	private String collateralType;

}
