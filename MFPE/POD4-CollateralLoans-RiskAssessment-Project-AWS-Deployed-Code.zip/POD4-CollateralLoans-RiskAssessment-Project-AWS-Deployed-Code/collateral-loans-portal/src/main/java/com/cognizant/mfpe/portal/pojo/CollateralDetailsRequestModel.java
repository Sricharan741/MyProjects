package com.cognizant.mfpe.portal.pojo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class CollateralDetailsRequestModel {
	private Double currentValue;
	private Double collateralValue;
	private Double ratePerSqFt;
	private Double depreciationRate;
	private String bankName;
	private Double interestRate;
	private Double depositAmount;
	private Integer lockPeriod;
}
