package com.cognizant.mfpe.portal.pojo;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class CollateralRisk {

	private Integer riskId;

	private Integer loanId;

	private BigDecimal riskPercent;

	private String dateAssessed;

}