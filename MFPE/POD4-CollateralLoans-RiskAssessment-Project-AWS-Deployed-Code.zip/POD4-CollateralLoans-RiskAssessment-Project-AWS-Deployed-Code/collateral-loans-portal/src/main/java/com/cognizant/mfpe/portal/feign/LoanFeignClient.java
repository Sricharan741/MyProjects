package com.cognizant.mfpe.portal.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.mfpe.portal.pojo.CollateralDetailsRequestModel;
import com.cognizant.mfpe.portal.pojo.CollateralType;
import com.cognizant.mfpe.portal.pojo.Customer;
import com.cognizant.mfpe.portal.pojo.Loan;
import com.cognizant.mfpe.portal.pojo.LoanDetailsResponseModel;

import feign.FeignException;

@FeignClient(name = "loan-management-service", url = "${loanServiceURL:http://34.228.37.236:9093/loanapi}")
public interface LoanFeignClient {

	@GetMapping("/getLoanDetails")
	public ResponseEntity<LoanDetailsResponseModel> getLoanDetails(@RequestParam Integer loanId,
			@RequestParam Integer customerId,
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws FeignException;

	@PostMapping("/saveCollaterals/{loanId}/{collateralId}/{collateralType}")
	public ResponseEntity<Boolean> saveCollaterals(@PathVariable Integer loanId, @PathVariable Integer collateralId,
			@PathVariable CollateralType collateralType, @RequestBody CollateralDetailsRequestModel requestModel,
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws FeignException;

	@GetMapping("/getAllCustomers")
	public ResponseEntity<List<Customer>> getAllCustomers(
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws FeignException;

	@GetMapping("/getAllLoanProducts")
	public ResponseEntity<List<Loan>> getAllLoanProducts(
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws FeignException;

}
