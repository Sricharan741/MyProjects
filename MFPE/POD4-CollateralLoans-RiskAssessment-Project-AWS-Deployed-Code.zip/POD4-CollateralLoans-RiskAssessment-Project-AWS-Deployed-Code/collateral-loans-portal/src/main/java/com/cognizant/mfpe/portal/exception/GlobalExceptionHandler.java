package com.cognizant.mfpe.portal.exception;

import java.time.LocalDateTime;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import feign.FeignException;
import lombok.extern.slf4j.Slf4j;

@ControllerAdvice(basePackages = "com.cognizant.mfpe.portal.controller")
@Slf4j
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler({ Exception.class, MissingRequestHeaderException.class })
	public ModelAndView handleAnyException(Exception ex, WebRequest request) {
		log.error(ex.getMessage());
		ApiErrorResponse errorResponse = new ApiErrorResponse(LocalDateTime.now(), HttpStatus.BAD_REQUEST);
		errorResponse.setLocalizedMessage(ex.getLocalizedMessage());
		ModelAndView errorPage = new ModelAndView("error-page");
		errorPage.addObject("errorResponse", errorResponse);
		return errorPage;
	}

	@ExceptionHandler(AuthorizationException.class)
	public ModelAndView handleGlobalException(AuthorizationException ex, WebRequest request) {
		log.error(ex.getMessage());
		ApiErrorResponse errorResponse = new ApiErrorResponse(LocalDateTime.now(), HttpStatus.BAD_REQUEST);
		errorResponse.setLocalizedMessage(ex.getLocalizedMessage());
		ModelAndView errorPage = new ModelAndView("error-page");
		errorPage.addObject("errorResponse", errorResponse);
		return errorPage;
	}

	@ExceptionHandler(FeignException.class)
	public Map<String, Object> handleFeignStatusException(FeignException e, HttpServletResponse response) {
		log.error(e.contentUTF8());
		response.setStatus(e.status());
		return new JSONObject(e.contentUTF8()).toMap();
	}
}
