package com.cognizant.mfpe.portal.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FormInputsGetRiskDetails {

	@Positive(message = "Loan Id must be greater than 0")
	@NotNull(message = "Loan Id must not be null")
	private Integer loanId;
}
