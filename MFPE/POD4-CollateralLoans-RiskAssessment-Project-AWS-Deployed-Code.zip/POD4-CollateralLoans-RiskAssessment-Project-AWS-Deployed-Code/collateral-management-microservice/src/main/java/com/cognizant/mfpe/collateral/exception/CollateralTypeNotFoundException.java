package com.cognizant.mfpe.collateral.exception;

public class CollateralTypeNotFoundException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CollateralTypeNotFoundException(String message) {
		super(message);
	}

}
