package com.cognizant.mfpe.collateral.ui;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@ApiModel(description = "Characteristics Of CollateralDetailsRequestModel")
public class CollateralDetailsRequestModel {
	@ApiModelProperty(notes = "Name of the Owner")
	private String ownerName;
	@ApiModelProperty(notes = "Owner Address")
	private String address;
	@ApiModelProperty(notes = "Current value of Collateral")
	private Double currentValue;
	@ApiModelProperty(notes = "Collateral value of CollateralType")
	private Double collateralValue;
	@ApiModelProperty(notes = "ratePerSqFt related to CollateralType REAL_ESTATE")
	private Double ratePerSqFt;
	@ApiModelProperty(notes = "depreciationRate related to CollateralType REAL_ESTATE")
	private Double depreciationRate;
	@ApiModelProperty(notes = "Bank name related to CollateralType CASH_DEPOSIT")
	private String bankName;
	@ApiModelProperty(notes = "Interest rate related to CollateralType CASH_DEPOSIT")
	private Double interestRate;
	@ApiModelProperty(notes = "Deposit amount related to CollateralType CASH_DEPOSIT")
	private Double depositAmount;
	@ApiModelProperty(notes = "lock period related to CollateralType CASH_DEPOSIT")
	private Integer lockPeriod;
}
