package com.cognizant.mfpe.collateral.service;

import java.time.LocalDate;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.cognizant.mfpe.collateral.entities.CollateralCashDeposit;
import com.cognizant.mfpe.collateral.entities.CollateralLoan;
import com.cognizant.mfpe.collateral.entities.CollateralRealEstate;
import com.cognizant.mfpe.collateral.entities.CollateralType;
import com.cognizant.mfpe.collateral.exception.CollateralLoanNotFoundException;
import com.cognizant.mfpe.collateral.repository.CashDepositRepository;
import com.cognizant.mfpe.collateral.repository.CollateralLoanRepository;
import com.cognizant.mfpe.collateral.repository.RealEstateRepository;
import com.cognizant.mfpe.collateral.ui.CollateralDetailsRequestModel;

@Service
public class CollateralServiceImpl implements CollateralService {

	private CollateralLoanRepository collateralLoanRepository;

	private RealEstateRepository realEstateRepository;

	private CashDepositRepository cashDepositRepository;

	private ModelMapper modelMapper;

	@Autowired
	public CollateralServiceImpl(CollateralLoanRepository collateralLoanRepository,
			RealEstateRepository realEstateRepository, CashDepositRepository cashDepositRepository,
			ModelMapper modelMapper) {
		super();
		this.collateralLoanRepository = collateralLoanRepository;
		this.realEstateRepository = realEstateRepository;
		this.cashDepositRepository = cashDepositRepository;
		this.modelMapper = modelMapper;
	}

	@Override
	public CollateralLoan getCollaterals(Integer loanId, Integer collateralId) throws CollateralLoanNotFoundException {
		// Check if collateral loan has an entry or not
		CollateralLoan collateralLoan = collateralLoanRepository.findByLoanIdAndCollateralId(loanId, collateralId);
		if (collateralLoan == null) {
			throw new CollateralLoanNotFoundException("Collateral Details not found for LoanId: " + loanId);
		}
		return collateralLoan;
	}

	@Override
	public Boolean saveCollaterals(Integer loanId, Integer collateralId, CollateralType collateralType,
			CollateralDetailsRequestModel requestModel) throws MethodArgumentTypeMismatchException {
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		// Map collateral to respective collateralType and save it
		if (collateralType.equals(CollateralType.REAL_ESTATE)) {
			CollateralRealEstate collateralRealEstate = modelMapper.map(requestModel, CollateralRealEstate.class);

			this.saveCollateralRealEstate(loanId, collateralId, collateralRealEstate);

			this.saveCollateralLoan(
					new CollateralLoan(loanId, collateralId, requestModel.getCollateralValue(), LocalDate.now()));
			return true;
		} else if (collateralType.equals(CollateralType.CASH_DEPOSIT)) {

			CollateralCashDeposit collateralCashDeposit = modelMapper.map(requestModel, CollateralCashDeposit.class);

			this.saveCollateralCashDeposit(loanId, collateralId, collateralCashDeposit);

			this.saveCollateralLoan(
					new CollateralLoan(loanId, collateralId, requestModel.getCollateralValue(), LocalDate.now()));
			return true;
		} else {
			return false;
		}

	}

	private void saveCollateralLoan(CollateralLoan collateralLoan) {
		collateralLoanRepository.save(collateralLoan);
	}

	private void saveCollateralRealEstate(Integer loanId, Integer collateralId,
			CollateralRealEstate collateralRealEstate) {
		// Set loanId, collateralId, collateralType for collateralRealEstate
		collateralRealEstate.setLoanId(loanId);
		collateralRealEstate.setCollateralId(collateralId);
		collateralRealEstate.setCollateralType("REAL_ESTATE");
		realEstateRepository.save(collateralRealEstate);
	}

	private void saveCollateralCashDeposit(Integer loanId, Integer collateralId,
			CollateralCashDeposit collateralCashDeposit) {
		// Set loanId, collateralId, collateralType for collateralCashDeposit
		collateralCashDeposit.setLoanId(loanId);
		collateralCashDeposit.setCollateralId(collateralId);
		collateralCashDeposit.setCollateralType("CASH_DEPOSIT");
		cashDepositRepository.save(collateralCashDeposit);
	}

}
