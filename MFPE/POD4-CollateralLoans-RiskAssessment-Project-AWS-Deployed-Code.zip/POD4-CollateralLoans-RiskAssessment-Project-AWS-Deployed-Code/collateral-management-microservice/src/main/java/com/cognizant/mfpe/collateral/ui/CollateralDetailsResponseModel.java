package com.cognizant.mfpe.collateral.ui;

import java.util.Map;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(description="Details of CollateralDetailsResponseModel")
public class CollateralDetailsResponseModel {
	@ApiModelProperty(notes="Response Details of Collateral Stored in Map<String,Object>")
	private Map<String, Object> collateralDetails;
}
