package com.cognizant.mfpe.collateral.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.mfpe.collateral.entities.CollateralRealEstate;

@Repository
public interface RealEstateRepository extends JpaRepository<CollateralRealEstate, Integer> {

}
