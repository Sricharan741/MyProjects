package com.cognizant.mfpe.authorization.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ApiModel(description="Model Object that contains User Credentials")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Entity
@Table(name = "users")
public class User {
	
	@ApiModelProperty(notes="Id of Model User")
	@Id
	@GeneratedValue
	private int id;
	
	@ApiModelProperty(notes="UserName of Model User")
	private String userName;
	
	
	@ApiModelProperty(notes="Password of Model User")
	private String password;
	
}
