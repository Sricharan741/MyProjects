package com.cognizant.mfpe.risk.pojo;

import javax.validation.constraints.Positive;

import com.sun.istack.NotNull;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RequiredCollateralDetails {

	@ApiModelProperty(notes = "CurrentValue of Collateral", name = "currentValue", dataType = "Double")
	@NotNull
	private Double currentValue;

	@ApiModelProperty(notes = "Rate Per Square Feet of the Property or Asset", name = "ratePerSqFt", dataType = "Double")
	@NotNull
	private Double ratePerSqFt;

	@ApiModelProperty(notes = "Depreciation rate is the percentage rate at which asset is depreciated across the estimated productive life of the asset", name = "depreciationRate", dataType = "Double")
	@NotNull
	private Double depreciationRate;

	@ApiModelProperty(notes = "InterestRate of Collateral Cash Deposit", name = "interestRate", dataType = "Double")
	@NotNull
	private Double interestRate;

	@ApiModelProperty(notes = "DepositAmount of Collateral Cash Deposit", name = "depositAmount", dataType = "Double")
	@NotNull
	private Double depositAmount;

	@ApiModelProperty(notes = "LockPeriod of Collateral Cash Deposit", name = "lockPeriod", dataType = "Integer")
	@NotNull
	@Positive
	private Integer lockPeriod;
}
