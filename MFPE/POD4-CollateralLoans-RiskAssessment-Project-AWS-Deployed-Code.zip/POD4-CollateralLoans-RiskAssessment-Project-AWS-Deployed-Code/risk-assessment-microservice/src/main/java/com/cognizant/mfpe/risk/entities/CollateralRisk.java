package com.cognizant.mfpe.risk.entities;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ApiModel(description = "This entity is to store details, Whenever Collateral Value Falls Below Sanctioned Loan, risk need to be calcualted")
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class CollateralRisk {

	@ApiModelProperty(notes = "Id of the Risk", name = "riskId", dataType = "Integer")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer riskId;

	@ApiModelProperty(notes = "LoanId of the customer", name = "loanId", dataType = "Integer")
	private Integer loanId;

	@ApiModelProperty(notes = "Percentage of risk", name = "riskPercent", dataType = "BigDecimal")
	private BigDecimal riskPercent;

	@ApiModelProperty(notes = "Date at which risk is raised", name = "dateAssessed", dataType = "LocalDate")
	private String dateAssessed;

	@ApiModelProperty(notes = "Current Market Value of the Collateral", name = "marketValue", dataType = "Double")
	@JsonIgnore
	private Double marketValue;

	@ApiModelProperty(notes = "Sanctioned loan Value", name = "sanctionedLoan", dataType = "Double")
	@JsonIgnore
	private Double sanctionedLoan;

}