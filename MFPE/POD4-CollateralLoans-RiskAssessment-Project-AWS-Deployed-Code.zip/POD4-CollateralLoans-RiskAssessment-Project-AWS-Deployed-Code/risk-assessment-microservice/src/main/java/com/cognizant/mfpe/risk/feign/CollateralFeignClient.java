package com.cognizant.mfpe.risk.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.mfpe.risk.pojo.CollateralDetailsResponseModel;

import feign.FeignException;

@FeignClient(name = "collateral-management-service", url = "${collateralServiceURL:http://18.204.225.247:9092/collateralapi}")
public interface CollateralFeignClient {

	@GetMapping("/getCollaterals")
	public ResponseEntity<CollateralDetailsResponseModel> getCollaterals(@RequestParam Integer loanId,
			@RequestParam Integer collateralId,
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws FeignException;
}
