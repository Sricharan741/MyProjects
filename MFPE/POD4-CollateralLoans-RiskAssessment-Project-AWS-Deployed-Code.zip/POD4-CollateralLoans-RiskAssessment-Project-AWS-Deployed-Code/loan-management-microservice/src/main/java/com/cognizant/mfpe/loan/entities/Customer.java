package com.cognizant.mfpe.loan.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ApiModel(description = "Details of model Customer")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Customer {

	@ApiModelProperty(notes = "Customer Id of Model Customer", name = "customerId", dataType = "Integer")
	@Id
	private Integer customerId;
	@ApiModelProperty(notes = "Name of the Customer", name = "customerName", dataType = "String")
	private String name;
	@ApiModelProperty(notes = "Email Id of the Customer", name = "emailId", dataType = "String")
	private String emailId;
	@ApiModelProperty(notes = "Mobile number of the Customer", name = "mobileNo", dataType = "String")
	private String mobileNo;
	@ApiModelProperty(notes = "Address of the Customer", name = "address", dataType = "String")
	private String address;

}
