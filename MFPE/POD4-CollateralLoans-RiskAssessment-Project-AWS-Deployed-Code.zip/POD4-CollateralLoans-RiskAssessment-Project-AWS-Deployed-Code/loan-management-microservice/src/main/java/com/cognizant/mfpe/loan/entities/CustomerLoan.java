package com.cognizant.mfpe.loan.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ApiModel(description = "Details of Model Customer Loan")
@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "customerloan")
public class CustomerLoan {

	@ApiModelProperty(notes = "LoanId  of the Customer Loan", name = "loanId", dataType = "Integer")
	@Id
	private Integer loanId;

	@ApiModelProperty(notes = "Loan Product Id  of the Customer Loan", name = "loanProductId", dataType = "Integer")
	@JsonIgnore
	private Integer loanProductId;

	@ApiModelProperty(notes = "Customer Id  of the Customer Loan", name = "customerId", dataType = "Integer")
	@JsonIgnore
	private Integer customerId;

	@ApiModelProperty(notes = "Loan principle  of the Customer Loan", name = "loanPrinciple", dataType = "Double")
	private Double loanPrincipal;

	@ApiModelProperty(notes = "Tenure  of the Customer Loan", name = "tenure", dataType = "Integer")
	private Integer tenure;

	@ApiModelProperty(notes = "Interest Rate of the Customer Loan", name = "interest", dataType = "Double")
	private Double interest;

	@ApiModelProperty(notes = "Emi  of the Customer Loan", name = "emi", dataType = "Double")
	@JsonIgnore
	private Double emi;

	@ApiModelProperty(notes = "Collateral Id  of the Customer Loan", name = "collateralId", dataType = "Integer")
	private Integer collateralId;

	@ApiModelProperty(notes = "Details of Loan Object", name = "loan", dataType = "Loan")
	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "loanProductId", insertable = false, updatable = false)
	private Loan loan;

	@ApiModelProperty(notes = "Details of Customer Object", name = "customer", dataType = "Customer")
	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "customerId", insertable = false, updatable = false)
	@JsonIgnore
	private Customer customer;

}