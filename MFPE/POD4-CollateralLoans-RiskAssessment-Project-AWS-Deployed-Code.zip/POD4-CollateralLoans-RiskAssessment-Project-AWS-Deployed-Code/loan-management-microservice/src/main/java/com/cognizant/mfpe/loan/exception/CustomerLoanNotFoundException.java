package com.cognizant.mfpe.loan.exception;

public class CustomerLoanNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public CustomerLoanNotFoundException(String message) {
		super(message);
	}

}
