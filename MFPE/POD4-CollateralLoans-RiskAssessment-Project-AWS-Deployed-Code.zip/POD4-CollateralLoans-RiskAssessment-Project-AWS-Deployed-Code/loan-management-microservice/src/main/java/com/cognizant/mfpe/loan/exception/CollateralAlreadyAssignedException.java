package com.cognizant.mfpe.loan.exception;

/**
 * Class for handling CollateralAlreadyExistsException
 *
 */
public class CollateralAlreadyAssignedException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	/**
	 * Constructor
	 * 
	 * @param message
	 */
	public CollateralAlreadyAssignedException(String message) {
		super(message);
	}
}
