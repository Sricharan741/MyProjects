package com.cognizant.mfpe.loan.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cognizant.mfpe.loan.pojo.CollateralType;
import com.cognizant.mfpe.loan.ui.CollateralDetailsRequestModel;

import feign.FeignException;

@FeignClient(name = "collateral-management-service", url = "${collateralServiceURL:http://18.204.225.247:9092/collateralapi}")
public interface CollateralFeignClient {

	@PostMapping("/saveCollaterals/{loanId}/{collateralId}/{collateralType}")
	public ResponseEntity<Boolean> saveCollaterals(@PathVariable Integer loanId, @PathVariable Integer collateralId,
			@PathVariable CollateralType collateralType, @RequestBody CollateralDetailsRequestModel requestModel,
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws FeignException;
}
