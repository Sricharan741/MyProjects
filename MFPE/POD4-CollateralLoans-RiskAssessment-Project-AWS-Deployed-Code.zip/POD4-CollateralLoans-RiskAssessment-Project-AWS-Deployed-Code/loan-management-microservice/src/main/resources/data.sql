insert into customer(customer_id, name, email_id, mobile_no, address) values(101,'Sampath','sampath123@gmail.com','7780184807','Vijayawada');
insert into customer(customer_id, name, email_id, mobile_no, address) values(102,'Sricharan','sricharan123@gmail.com','9874561231','Kolkata');
insert into customer(customer_id, name, email_id, mobile_no, address) values(103,'Mahesh','mahesh123@gmail.com','8567891232','Bangalore');
insert into customer(customer_id, name, email_id, mobile_no, address) values(104,'Saikrishna','saikrishna123@gmail.com','9569891232','Hyderabad');
insert into customer(customer_id, name, email_id, mobile_no, address) values(105,'Hemanth','hemanthmhk@gmail.com','9848245569','Ananthapur');
insert into customer(customer_id, name, email_id, mobile_no, address) values(106,'Bhanu','bhanu@gmail','7894561592','Delhi');
insert into customer(customer_id, name, email_id, mobile_no, address) values(107,'Harsha','harsha@gmail.com','9000874152','Kerela');



insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1001,'Home Loan',3000000,10.5,48,'REAL_ESTATE');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1002,'Home Loan',1100000,9.5,40,'CASH_DEPOSIT');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1003,'Car Loan',1800000,8.5,36,'REAL_ESTATE');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1004,'Car Loan',1700000,9.5,24,'CASH_DEPOSIT');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1005,'Education Loan',1800000,6.5,60,'CASH_DEPOSIT');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1006,'Medical Loan',1500000,6,25,'REAL_ESTATE');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1007,'Medical Loan',1500000,12,26,'CASH_DEPOSIT');




insert into customerloan(loan_id,loan_product_id,customer_id,loan_principal,interest,tenure,emi,collateral_id) values(10001,1001,101,2500000,10.5,48,64008,NULL);
insert into customerloan(loan_id,loan_product_id,customer_id,loan_principal,interest,tenure,emi,collateral_id) values(10002,1002,102,900000,9.5,40,26338,NULL);
insert into customerloan(loan_id,loan_product_id,customer_id,loan_principal,interest,tenure,emi,collateral_id) values(10003,1003,103,1500000,8.5,36,47351,NULL);
insert into customerloan(loan_id,loan_product_id,customer_id,loan_principal,interest,tenure,emi,collateral_id) values(10004,1004,104,1200000,9.5,24,55097,NULL);
insert into customerloan(loan_id,loan_product_id,customer_id,loan_principal,interest,tenure,emi,collateral_id) values(10005,1005,105,1300000,6.5,60,25436,NULL);
insert into customerloan(loan_id,loan_product_id,customer_id,loan_principal,interest,tenure,emi,collateral_id) values(10006,1006,106,1000000,6,25,42652,NULL);
insert into customerloan(loan_id,loan_product_id,customer_id,loan_principal,interest,tenure,emi,collateral_id) values(10007,1007,107,7000000,12,26,30708,NULL);