package com.cognizant.mfpe.collateral.service;

import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.cognizant.mfpe.collateral.entities.CollateralLoan;
import com.cognizant.mfpe.collateral.entities.CollateralType;
import com.cognizant.mfpe.collateral.ui.CollateralDetailsRequestModel;

public interface CollateralService {

	public Boolean saveCollaterals(Integer loanId, Integer collateralId, CollateralType collateralType,
			CollateralDetailsRequestModel requestModel) throws MethodArgumentTypeMismatchException;

	public CollateralLoan getCollaterals(Integer loanId, Integer collateralId);

}
