package com.cognizant.mfpe.collateral.exception;

import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * This is the class for Global Exception Handling
 */
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	/**
	 * This handles all the response for CollateralTypeNotFoundException and
	 * CollateralLoanNotFoundException
	 * 
	 * @param exception
	 * @return ResponseEntity<ApiErrorResponse>
	 */

	@ExceptionHandler({ CollateralTypeNotFoundException.class, CollateralLoanNotFoundException.class })
	public ResponseEntity<ApiErrorResponse> handleCollateralTypeOrLoanNotFoundException(Exception ex,
			WebRequest request) {
		log.error(ex.getMessage());
		ApiErrorResponse errorResponse = new ApiErrorResponse(LocalDateTime.now(), HttpStatus.BAD_REQUEST);
		errorResponse.setMessage(ex.getMessage());
		errorResponse.setLocalizedMessage(ex.getLocalizedMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler({ Exception.class, MissingRequestHeaderException.class })
	public ResponseEntity<ApiErrorResponse> handleAnyException(Exception ex, WebRequest request) {
		log.error(ex.getMessage());
		ApiErrorResponse errorResponse = new ApiErrorResponse(LocalDateTime.now(), HttpStatus.BAD_REQUEST);
		errorResponse.setLocalizedMessage(ex.getLocalizedMessage());
		errorResponse.setMessage(ex.getMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public ResponseEntity<ApiErrorResponse> handleMethodArgumentTypeMismatchException(Exception ex,
			WebRequest request) {
		log.error(ex.getMessage());
		ApiErrorResponse errorResponse = new ApiErrorResponse(LocalDateTime.now(), HttpStatus.BAD_REQUEST);
		errorResponse.setLocalizedMessage("Invalid Collateral Type for given loanId");
		errorResponse.setMessage("Invalid Collateral Type for given loanId");
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(AuthorizationException.class)
	public ResponseEntity<ApiErrorResponse> handleGlobalException(AuthorizationException ex, WebRequest request) {
		log.error(ex.getMessage());
		ApiErrorResponse errorResponse = new ApiErrorResponse(LocalDateTime.now(), HttpStatus.UNAUTHORIZED);
		errorResponse.setLocalizedMessage(ex.getLocalizedMessage());
		errorResponse.setMessage(ex.getMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.UNAUTHORIZED);
	}

}