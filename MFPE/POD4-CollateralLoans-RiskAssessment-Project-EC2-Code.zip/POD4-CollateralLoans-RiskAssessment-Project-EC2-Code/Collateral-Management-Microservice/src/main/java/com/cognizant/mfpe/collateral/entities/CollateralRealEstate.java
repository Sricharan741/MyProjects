package com.cognizant.mfpe.collateral.entities;

import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ApiModel(description = "Details of Real Estate Collateral")
@Entity
@NoArgsConstructor
@Getter
@Setter
@Inheritance(strategy = InheritanceType.JOINED)
public class CollateralRealEstate extends Collateral {

	@ApiModelProperty(notes = "Rate Per Square Feet of the Property or Asset", name = "ratePerSqFt", dataType = "Double")
	private Double ratePerSqFt;
	@ApiModelProperty(notes = "Depreciation rate is the percentage rate at which asset is depreciated across the estimated productive life of the asset", name = "depreciationRate", dataType = "Double")
	private Double depreciationRate;
}
