//package com.cognizant.mfpe.risk.controller;
//
//import static org.junit.Assert.assertEquals;
//import static org.mockito.Mockito.when;
//
//import java.time.LocalDate;
//
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//
//import com.cognizant.mfpe.collateral.entities.CollateralLoan;
//import com.cognizant.mfpe.collateral.repository.CashDepositRepository;
//import com.cognizant.mfpe.collateral.repository.CollateralLoanRepository;
//import com.cognizant.mfpe.collateral.repository.RealEstateRepository;
//import com.cognizant.mfpe.collateral.service.CollateralServiceImpl;
//
//@SpringBootTest
//public class RiskRestController {
//	@InjectMocks
//	public CollateralServiceImpl service;
//	
//	@MockBean
//	public CollateralLoanRepository loanRepo;
//
//	@Mock
//	public CashDepositRepository cashRepo;
//
//	@Mock
//	public RealEstateRepository estateRepo;
//
//	@Test
//	public void saveCollateralLoanTest() {
//		CollateralLoan collateralLoan = new CollateralLoan(1, 1, 2500000d, LocalDate.now());
//		when(loanRepo.save(Mockito.any())).thenReturn(collateralLoan);
//		assertEquals(loanRepo.save(collateralLoan),collateralLoan);
////		System.out.println(collateralLoan.getCollateralId());
////		System.out.println(collateralLoan.getCollateralValue());
////		System.out.println(collateralLoan.getCollateral());
////		System.out.println(collateralLoan.getLoanId());
////		System.out.println(collateralLoan.getPledgedDate());
//		
//	}
//	
//	
//}
