package com.cognizant.mfpe.risk.pojo;

import java.util.Map;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ApiModel(description = "Collateral Details Which need to be send over a map")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class CollateralDetailsResponseModel {

	@ApiModelProperty(notes = "All Collateral Details", name = "collateralDetails", dataType = "Map")
	private Map<String, Object> collateralDetails;
}
