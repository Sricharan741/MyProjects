package com.cognizant.mfpe.risk.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.mfpe.risk.pojo.LoanDetailsResponseModel;

import feign.FeignException;

@FeignClient(name = "loan-management-service", url = "${loanServiceURL:http://localhost:9093/loanapi}")
public interface LoanFeignClient {

	@GetMapping("/getLoanDetails")
	public ResponseEntity<LoanDetailsResponseModel> getLoanDetails(@RequestParam Integer loanId,
			@RequestParam Integer customerId,@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws FeignException;
}
