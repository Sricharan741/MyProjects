package com.cognizant.mfpe.risk;

import java.io.BufferedReader;
import java.io.FileReader;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;

import com.cognizant.mfpe.risk.entities.CollateralMarketValue;
import com.cognizant.mfpe.risk.repository.CollateralMarketValueRepository;

@SpringBootApplication
@EnableFeignClients
@EnableEurekaClient
public class RiskAssessmentApplication implements CommandLineRunner {

	@Autowired
	private CollateralMarketValueRepository collateralMarketValueRepository;

	@Value("${csv-filename}")
	private String fileName;

	public static void main(String[] args) {
		SpringApplication.run(RiskAssessmentApplication.class, args);
	}

	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}

	@Override
	public void run(String... args) throws Exception {
		String line = null;
		String splitBy = ",";
		try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
			br.readLine(); // skip reading table headings
			while ((line = br.readLine()) != null) // returns a Boolean value
			{
				String[] rowData = line.split(splitBy); // use comma as separator
				Integer loanId = Integer.parseInt(rowData[0]);
				Integer customerId = Integer.parseInt(rowData[1]);
				String collateralType = rowData[2];
				Double marketValue = Double.parseDouble(rowData[3]);
				collateralMarketValueRepository.save(CollateralMarketValue.builder().loanId(loanId)
						.customerId(customerId).collateralType(collateralType).marketValue(marketValue).build());
			}
		}
	}

}
