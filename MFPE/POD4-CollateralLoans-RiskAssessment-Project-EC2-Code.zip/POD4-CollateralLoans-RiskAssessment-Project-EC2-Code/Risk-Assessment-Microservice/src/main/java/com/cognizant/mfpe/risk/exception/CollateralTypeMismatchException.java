package com.cognizant.mfpe.risk.exception;

public class CollateralTypeMismatchException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CollateralTypeMismatchException(String message) {
		super(message);
	}

}
