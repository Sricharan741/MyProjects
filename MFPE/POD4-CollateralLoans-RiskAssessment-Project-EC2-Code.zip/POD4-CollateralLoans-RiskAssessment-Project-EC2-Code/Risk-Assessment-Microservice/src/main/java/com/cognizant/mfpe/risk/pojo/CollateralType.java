package com.cognizant.mfpe.risk.pojo;

public enum CollateralType {
	REAL_ESTATE, CASH_DEPOSIT
}
