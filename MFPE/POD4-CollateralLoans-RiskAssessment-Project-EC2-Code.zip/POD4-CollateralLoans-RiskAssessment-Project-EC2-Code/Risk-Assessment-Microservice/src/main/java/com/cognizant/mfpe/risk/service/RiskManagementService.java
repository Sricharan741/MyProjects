package com.cognizant.mfpe.risk.service;

import java.util.List;

import com.cognizant.mfpe.risk.entities.CollateralMarketValue;
import com.cognizant.mfpe.risk.entities.CollateralRisk;

public interface RiskManagementService {

	public CollateralRisk getCollateralRisk(Integer loanId, String requestTokenHeader) throws Exception;
	
	public List<CollateralMarketValue> getCollateralMarketValues();

}