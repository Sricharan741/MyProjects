package com.cognizant.mfpe.portal.pojo;

public enum CollateralType {
	REAL_ESTATE, CASH_DEPOSIT
}
