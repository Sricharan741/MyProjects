package com.cognizant.mfpe.portal.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cognizant.mfpe.portal.exception.AuthorizationException;
import com.cognizant.mfpe.portal.feign.AuthorizationClient;
import com.cognizant.mfpe.portal.feign.LoanFeignClient;
import com.cognizant.mfpe.portal.model.FormInputsGetLoanDetails;
import com.cognizant.mfpe.portal.model.FormInputsSaveCollateralDetails;
import com.cognizant.mfpe.portal.pojo.CollateralDetailsRequestModel;
import com.cognizant.mfpe.portal.pojo.CollateralType;
import com.cognizant.mfpe.portal.pojo.Customer;
import com.cognizant.mfpe.portal.pojo.Loan;
import com.cognizant.mfpe.portal.pojo.LoanDetailsResponseModel;

import feign.FeignException;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class LoanController {

	private LoanFeignClient loanFeignClient;

	private AuthorizationClient authorizationClient;

	private ModelMapper modelMapper;

	private final String message = "Authorization Failed";

	@Autowired
	public LoanController(LoanFeignClient loanFeignClient, AuthorizationClient authorizationClient,
			ModelMapper modelMapper) {
		super();
		this.loanFeignClient = loanFeignClient;
		this.authorizationClient = authorizationClient;
		this.modelMapper = modelMapper;
	}

	@GetMapping("/getLoanDetailsForm")
	public String getLoanDetailsForm(
			@ModelAttribute("formInputsGetLoanDetails") FormInputsGetLoanDetails formInputsGetLoanDetails,
			@ModelAttribute("loanDetailsResponse") LoanDetailsResponseModel loanDetailsResponse,
			@ModelAttribute("formInputsSaveCollateralDetails") FormInputsSaveCollateralDetails formInputsSaveCollateralDetails,
			@ModelAttribute("response") String errorMessage, Model model, HttpServletRequest request)
			throws AuthorizationException {
		// check for authorization
		if (!isAuthorized(request)) {
			throw new AuthorizationException(message);
		}
		model.addAttribute("formInputsGetLoanDetails", formInputsGetLoanDetails);

		if (loanDetailsResponse == null || loanDetailsResponse.getLoanId() == null) {
			model.addAttribute("loanDetailsResponse", null);
		} else {
			model.addAttribute("loanDetailsResponse", loanDetailsResponse);
		}
		model.addAttribute("formInputsSaveCollateralDetails", formInputsSaveCollateralDetails);
		model.addAttribute("response", errorMessage);
		return "loan-details-form";
	}

	@GetMapping("/getLoanDetails")
	public ModelAndView getLoanDetails(
			@Valid @ModelAttribute("formInputsGetLoanDetails") FormInputsGetLoanDetails formInputsGetLoanDetails,
			BindingResult result, HttpServletRequest request, RedirectAttributes redirect, ModelMap map)
			throws AuthorizationException, Exception {

		// check for authorization
		if (!isAuthorized(request)) {
			throw new AuthorizationException(message);
		}
		// check for validations
		if (result.hasErrors()) {
			return this.redirectToGetLoanForm(redirect, "Input is invalid", null, formInputsGetLoanDetails);
		}

		// get loanId and customerId
		Integer loanId = formInputsGetLoanDetails.getLoanId();
		Integer customerId = formInputsGetLoanDetails.getCustomerId();
		LoanDetailsResponseModel loanDetailsResponse = null;

		// getLoanDetails by using feign client
		try {
			loanDetailsResponse = loanFeignClient
					.getLoanDetails(loanId, customerId, (String) request.getSession().getAttribute("Authorization"))
					.getBody();
			map.put("loanDetailsResponse", loanDetailsResponse);
			map.put("formInputsGetLoanDetails", formInputsGetLoanDetails);
			return new ModelAndView("loan-details-form");
		} catch (FeignException ex) {
			if (!ex.contentUTF8().startsWith("{")) {
				throw new Exception(ex.getLocalizedMessage());
			}
			JSONObject json = new JSONObject(ex.contentUTF8());
			return this.redirectToGetLoanForm(redirect, json.get("localizedMessage").toString(), loanDetailsResponse,
					formInputsGetLoanDetails);
		}
	}

	@PostMapping("/getCollateralForm")
	public ModelAndView getCollateralForm(
			@ModelAttribute("loanDetailsResponse") LoanDetailsResponseModel loanDetailsResponse, BindingResult result,
			@ModelAttribute("formInputsGetLoanDetails") FormInputsGetLoanDetails formInputsGetLoanDetails,
			HttpServletRequest request, RedirectAttributes redirect, ModelAndView modelAndView)
			throws AuthorizationException, Exception {

		// check for authorization
		if (!isAuthorized(request)) {
			throw new AuthorizationException(message);
		}
		// check for validations
		if (result.hasErrors()) {
			return this.redirectToGetLoanForm(redirect, "Invalid Input", loanDetailsResponse, formInputsGetLoanDetails);
		}

		// save loanId, collateralId, collateralType to forward the data to save
		// collateral details method
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		FormInputsSaveCollateralDetails collateralObj = modelMapper.map(loanDetailsResponse,
				FormInputsSaveCollateralDetails.class);
		modelAndView.addObject("collateralObj", collateralObj);
		modelAndView.addObject("loanDetailsResponse", loanDetailsResponse);
		if (loanDetailsResponse.getCollateralType().equals("REAL_ESTATE")) {
			modelAndView.setViewName("real-estate-form");
		} else {
			modelAndView.setViewName("cash-deposit-form");
		}
		return modelAndView;

	}

	@PostMapping("/submitCollateral")
	public ModelAndView submitCollaterals(
			@ModelAttribute("collateralObj") FormInputsSaveCollateralDetails formCollateralDetails,
			BindingResult result, ModelAndView model, HttpServletRequest request, RedirectAttributes redirect)
			throws AuthorizationException, Exception {

		// check for authorization
		if (!isAuthorized(request)) {
			throw new AuthorizationException(message);
		}
		// check for validations
		if (result.hasErrors()) {
			model.addObject("collateralObj", formCollateralDetails);
			String collateralType = formCollateralDetails.getCollateralType();
			if (collateralType.equals("REAL_ESTATE")) {
				model.setViewName("real-estate-form");
			} else {
				model.setViewName("cash-deposit-form");
			}
			return model;
		}
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		Integer loanId = formCollateralDetails.getLoanId();
		CollateralType collateralType = CollateralType.valueOf(formCollateralDetails.getCollateralType());
		CollateralDetailsRequestModel requestModel = modelMapper.map(formCollateralDetails,
				CollateralDetailsRequestModel.class);
		try {
			loanFeignClient.saveCollaterals(loanId, 0, collateralType, requestModel,
					(String) request.getSession().getAttribute("Authorization"));
			return this.redirectToGetLoanForm(redirect, null, null,
					new FormInputsGetLoanDetails(loanId, formCollateralDetails.getCollateralId()));
		} catch (FeignException ex) {
			if (!ex.contentUTF8().startsWith("{")) {
				throw new Exception(ex.getLocalizedMessage());
			}
			JSONObject json = new JSONObject(ex.contentUTF8());
			log.info(ex.contentUTF8());
			model.addObject("response", json.get("localizedMessage").toString());
			if (collateralType.name().equals("REAL_ESTATE")) {
				model.setViewName("real-estate-form");
			} else {
				model.setViewName("cash-deposit-form");
			}
			return model;
		}
	}

	@GetMapping("/getCustomers")
	public ModelAndView getAllCustomers(HttpServletRequest request, ModelAndView model) throws AuthorizationException {
		if (!isAuthorized(request)) {
			throw new AuthorizationException(message);
		}
		model.setViewName("customers-table");
		List<Customer> customers = loanFeignClient
				.getAllCustomers((String) request.getSession().getAttribute("Authorization")).getBody();
		model.addObject("customerList", customers);
		return model;
	}

	@GetMapping("/getLoanProducts")
	public ModelAndView getAllLoanProducts(HttpServletRequest request, ModelAndView model)
			throws AuthorizationException {
		if (!isAuthorized(request)) {
			throw new AuthorizationException(message);
		}
		model.setViewName("loan-products-table");
		List<Loan> loanProducts = loanFeignClient
				.getAllLoanProducts((String) request.getSession().getAttribute("Authorization")).getBody();
		model.addObject("loanProductList", loanProducts);
		return model;
	}

	private boolean isAuthorized(HttpServletRequest request) throws AuthorizationException {
		try {
			return authorizationClient.authorizeTheRequest((String) request.getSession().getAttribute("Authorization"));
		} catch (FeignException ex) {
			throw new AuthorizationException(message);
		}
	}

	private ModelAndView redirectToGetLoanForm(RedirectAttributes redirect, String errorMessage,
			Object loanDetailsResponseModel, Object formInputsGetLoanDetails) {
		redirect.addFlashAttribute("errorMessage", errorMessage);
		redirect.addFlashAttribute("loanDetailsResponse", loanDetailsResponseModel);
		redirect.addFlashAttribute("formInputsGetLoanDetails", formInputsGetLoanDetails);
		return new ModelAndView("redirect:/getLoanDetailsForm");
	}
}
