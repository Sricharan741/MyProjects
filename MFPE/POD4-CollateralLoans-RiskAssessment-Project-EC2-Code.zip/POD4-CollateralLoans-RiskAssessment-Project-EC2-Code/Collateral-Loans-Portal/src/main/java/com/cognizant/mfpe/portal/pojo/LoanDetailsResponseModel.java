package com.cognizant.mfpe.portal.pojo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class LoanDetailsResponseModel {
	private Integer loanId;
	private Double sanctionedLoanAmount;
	private Integer tenure;
	private Double interest;
	private Integer collateralId;
	private String collateralType;
}
