package com.cognizant.mfpe.portal.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * This class is for customizing the exception handler
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ApiErrorResponse {

	private LocalDateTime timestamp;
	private HttpStatus status;
//	private String message;
	private String localizedMessage;

	/**
	 * 
	 * @param httpStatus
	 */
	public ApiErrorResponse(LocalDateTime timestamp, HttpStatus status) {
		this.timestamp = timestamp;
		this.status = status;
	}

}
