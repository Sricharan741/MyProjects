package com.cognizant.mfpe.portal.pojo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Customer {

	private Integer customerId;
	private String name;
	private String emailId;
	private String mobileNo;
	private String address;

}
