package com.cognizant.mfpe.portal.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.mfpe.portal.pojo.CollateralMarketValue;
import com.cognizant.mfpe.portal.pojo.CollateralRisk;

import feign.FeignException;

@FeignClient(name = "risk-management-service", url = "${riskServiceURL:http://localhost:9094/riskapi}")
public interface RiskFeignClient {
	@GetMapping(value = "/getCollateralRisk")
	public ResponseEntity<CollateralRisk> getCollateralRisk(@RequestParam Integer loanId,
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws FeignException;

	@GetMapping(value = "/getCollateralMarketValues")
	public ResponseEntity<List<CollateralMarketValue>> getCollateralMarketValues(
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws FeignException;
}
