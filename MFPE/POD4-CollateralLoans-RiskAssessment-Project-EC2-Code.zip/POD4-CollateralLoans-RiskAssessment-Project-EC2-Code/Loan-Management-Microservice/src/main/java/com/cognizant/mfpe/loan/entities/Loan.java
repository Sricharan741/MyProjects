package com.cognizant.mfpe.loan.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ApiModel(description = "Details of Model Loan")
@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Loan {

	@ApiModelProperty(notes = "product id of Loan", name = "loanProductId", dataType = "Integer")
	@Id
	private Integer loanProductId;
	@ApiModelProperty(notes = "product name of Loan", name = "loanProdutName", dataType = "String")
	private String loanProductName;
	@ApiModelProperty(notes = "Maximum Loan Eligible for each Account", name = "maxLoanEligible", dataType = "Double")
	private Double maxLoanEligible;
	@ApiModelProperty(notes = "Interest rate of the Loan", name = "interestRate", dataType = "Double")
	private Double interestRate;
	@ApiModelProperty(notes = "Tenure of the loan", name = "tenure", dataType = "Integer")
	private Integer tenure;
	@ApiModelProperty(notes = "Collateral Type of the Loan which may be REAL_ESTATE,CASH_DEPOSIT", name = "loanProductId", dataType = "Integer")
	private String collateralType;

}
