<?php
    error_reporting(true);
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    class MySQLDatabase
    {
        private $servername;
        private $username;
        private $password;
        private $dbname;
        public static $con_failed_status;
        public static $con;
        public static $baseURL;
        public function __construct()
        {
           // ini_set('display_errors',1); error_reporting(E_ALL);
            $this->servername = 'shareddb-p.hosting.stackcp.net';
            $this->username = 'user-313135c319';
            $this->password = '5=h4eLTs<Gyx';
            $this->dbname = 'history-313135c319';
            self::$baseURL = 'https://market.todaypricerates.com/';
            self::$con_failed_status= false;
            self::$con = mysqli_connect($this->servername, $this->username, $this->password, $this->dbname);
            if (mysqli_connect_error()) {
                echo '<br>Database Connection Unsuccessful<br>';
                self::$con_failed_status=true;
            	$subject="Database Connection Error For Cron Job(ENTIRE DISTRICTS)";
            	$msg='<h3 style="text-decoration:underline;">Failed to connect to MySQL Database: (' 
            	        .mysqli_connect_errno() 
            	        .')</h3><h4 style="color:black;">'
            	        .mysqli_connect_error()
            	        .'<br>Invalid Credentials...</h4>';
                sendEmail($subject,$msg);
            }
            else{
                echo 'Database Connection successful<br>';
            }
            return self::$con;
        }
        public function getConnection(){
            if(!self::$con){
                return new MySQLDatabase();
            }else{
                return self::$con;
            }
        }
        public function checkAndRestoreConnection(){
            if(self::$con_failed_status){
                echo 'Connection re-established successfully<br>';
                return mysqli_connect($this->servername, $this->username, $this->password, $this->dbname);
            }else{
                echo 'Connection is good<br>';
                return self::$con;
            }
        }
        public function closeConnection(){
            mysqli_close(self::$con);
            self::$con_failed_status=true;
            echo 'Connection closed successfully<br>';
        }
    }
    $sqldb=new MySQLDatabase();
?>