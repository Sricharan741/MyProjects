<?php
    require_once('mysql_dbconfig.php');
    //echo file_get_contents("temp.json");
    //echo json_encode(json_decode(file_get_contents("temp.json")),JSON_UNESCAPED_UNICODE);
    $date='2020-06-20';
    $state='Telangana';
    $district='Warangal';
    $stmt = MySQLDatabase::$con->prepare("SELECT details FROM veg_prices_history WHERE date=? AND state=? AND district=? limit 1");
        $stmt->bind_param('sss',$date,$state,$district);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->free_result();
        $stmt->close();
        if($result->num_rows == 1){
            $value = $result->fetch_object();
            $json_data=$value->details;
            echo $json_data;
        }
        else{
            echo '';
        }
        $sqldb->closeConnection();
?>