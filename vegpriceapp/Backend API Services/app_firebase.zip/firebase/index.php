<?php
    
    //include(__DIR__."/includes/dbconfig.php");// Get firebase database
    require_once(__DIR__."/mysql_dbconfig.php");
    use MySQLDatabase;
    $states=array("Andhra Pradesh","Telangana");
    $districts_ts=array("Adilabad", "Hyderabad","Karimnagar","Khammam","Mahbubnagar","Nalgonda","Nizamabad","Sangareddi","Warangal");
    //$districts_ap=array("Anantapur","Chittoor","East Godavari","Guntur","Kadapa","Krishna","Kurnool","Nellore", "Prakasam","Srikakulam","Visakhapatnam","Vizianagaram","West Godavari");
    $districts_ap=array("Anantapur","Chittoor","Kakinada","Guntur","Kadapa","Machilipatnam","Kurnool","Nellore", "Ongole","Srikakulam","Visakhapatnam","Vizianagaram","Eluru");
    date_default_timezone_set("Asia/Kolkata");
    $date=date("Y-m-d");
    class BackEnd extends MySQLDatabase{
        
    }
    foreach($states as $curState){
        if(strcmp($curState,"Andhra Pradesh")==0){
            echo $curState.'<br><br>';
            foreach($districts_ap as $curDistrict){
                $URL = MySQLDatabase::$baseURL.str_replace(' ','-',($curDistrict.' vegetables price in '.$curState));
                $curDistrict=setDistrict($curDistrict);
                echo $curDistrict.' ['.$URL.']<br>';
                getData($URL,$date,$curState,$curDistrict);
            }
        }
        else{
            echo $curState.'<br><br>';
            foreach($districts_ts as $curDistrict){
                $URL = MySQLDatabase::$baseURL.str_replace(' ','-',($curDistrict.' vegetables price in '.$curState));
                $curDistrict=setDistrict($curDistrict);
                echo $curDistrict.' ['.$URL.']<br>';
                getData($URL,$date,$curState,$curDistrict);
            }
        }
    }
    
    //scarpeDataFromURL($url,$date,$state,$district);
    $sqldb->closeConnection();
    
    function setDistrict($districtName){
        // Converting to Actual district names stored inside database
        if(strcmp($districtName,"Machilipatnam")==0){
            return 'Krishna';
        }
        elseif(strcmp($districtName,"Kakinada")==0){
            return 'East Godavari';
        }
        elseif(strcmp($districtName,"Ongole")==0){
            return 'Prakasam';
        }
        elseif(strcmp($districtName,"Eluru")==0){
            return 'West Godavari';
        }
        else{
            return $districtName;
        }
    }
    
    function getData($url,$date,$state,$district)
    {   
        MySQLDatabase::$con = $GLOBALS['sqldb']->checkAndRestoreConnection();
    	$json_data = checkDatabaseForJSONData(MySQLDatabase::$con,$date,$state,$district);
    	if($json_data != '')
    	{
    	    echo 'Data Exists in Database<br>';
    	    //scarpeDataFromURL($url,$date,$state,$district);
    	    //echo $json_data;
    	    //storeDataIntoFirebase($date,$state,$district,json_decode($json_data));
    	    //scarpeDataFromURL($url,$date,$state,$district);
    	}
        else{
            echo 'No Data Exists in Database<br>';
            //if(strcmp($district,'Warangal')==0){
                scarpeDataFromURL($url,$date,$state,$district);
            //}
    	}
    	//$GLOBALS['db']->closeConnection();
    }
    
    function checkDataBaseForJSONData($con,$date,$state,$district){
        //if(!$GLOBALS['con_closed_status']){
        //}
        $stmt = MySQLDatabase::$con->prepare('SELECT details FROM veg_prices_history WHERE date=? AND state=? AND district=? limit 1');
        $stmt->bind_param('sss', $date,$state,$district);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->free_result();
        $stmt->close();
        if($result->num_rows == 1){
            $value = $result->fetch_object();
            $json_data=$value->details;
            return $json_data;
        }
        else{
            return '';
        }
    }
    
    function storeDataIntoFirebase($date,$state,$district,$json_data){
        $ref = 'states/'.$state.'/districts/'.$district.'/'.$date.'/details';
        //$ref = '{'.$date.','.$state.','.$district.'}';
        echo 'Reference:"'.$ref.'"<br>';
        $database=$GLOBALS['database'];
        $database->getReference($ref)->set($json_data);
        //$database->getReference($ref)->remove(json_decode(file_get_contents('sangareddi_json.json')));
        echo "Data from firebase database:<br>";
        $data = $database->getReference($ref)->getSnapshot()->getValue();
        foreach($data as $key => $data1){
           echo $data1['vegname'].'<br>';
        }
    }
    function storeDataIntoSqlDatabase($date,$state,$district,$json_data){
        $data=checkDataBaseForJSONData(MySQLDatabase::$con,$date,$state,$district);
        if($data){
            $stmt = MySQLDatabase::$con->prepare('UPDATE veg_prices_history SET details=? WHERE date=?');
            $stmt->bind_param('ss', $json_data,$date);
            echo 'Data Successfully Updated<br>';
        }
        else{
            $stmt = MySQLDatabase::$con->prepare('INSERT INTO veg_prices_history(date,state,district,details) VALUES (?,?,?,?)');
            $stmt->bind_param('ssss', $date,$state,$district,$json_data);
            echo 'Data Successfully Inserted<br>';
        }
        $stmt->execute();
        $stmt->close();
    }
    function scarpeDataFromURL($url,$date,$state,$district)
    { 
        try 
        {  
        	$html=file_get_contents($url);
        	$DOM=new DOMDocument();
        	libxml_use_internal_errors(true); // disables the standard libxml errors and enables user error handling.
        	if(!empty($html)){ //if any html is actually returned
            	
            	$DOM->loadHTML($html);
            	libxml_clear_errors(); //remove errors for yucky html
            	$finder=new DomXPath($DOM);
            	$row_nodes=$finder->query("//div[@class='Row']");
            	if($row_nodes->length>0){
                	
                	$json_out=array();
                	foreach($row_nodes as $row_node) {
                		
                		//$full_content = innerHTML($node);
                		//$DOM->loadHTML($full_content);
                		//$Cell_finder=new DomXPath($DOM);
                		$cell_nodes = $finder->query("div[@class='Cell']",$row_node);
                        // WANT TO STORE DATA WITH RUPEE SYMBOL USE THIS
                        /*
                        $vegname = $cell_nodes[0]->nodeValue;
                        $market_price = $cell_nodes[2]->nodeValue;
                        $retail_price = $cell_nodes[3]->nodeValue;
                        $shopping_price = $cell_nodes[4]->nodeValue;
                        */
                		
                		// WANT TO STORE DATA WITHOUT RUPEE SYMBOL USE THIS
                		$vegname = $cell_nodes[0]->nodeValue;
                        $market_price = json_encode($cell_nodes[2]->nodeValue);
                        $retail_price = json_encode($cell_nodes[3]->nodeValue);
                        $shopping_price = json_encode($cell_nodes[4]->nodeValue);
                		$market_price=substr($market_price,9,strlen($market_price)-10);
                		$retail_price=substr($retail_price,9,strlen($retail_price)-10);
                		$shopping_price=substr($shopping_price,9,strlen($shopping_price)-10);
                		
                		$json_out[]=array("vegname"=>$vegname,"market"=>$market_price,"retail"=>$retail_price,"shopping"=>$shopping_price);
                		
                	    
                	    
                	}//FOREACH LOOP END
                	//header('Content-Type: application/json');
                    if(count($json_out)>0){
                      //storeFirebase($date,$state,$district,$json_out);
                      //$json_data=json_encode($json_out,JSON_UNESCAPED_UNICODE);
                      //echo $json_data;
                      $json_data=json_encode($json_out);
                      //echo $json_data;
                      storeDataIntoSqlDatabase($date,$state,$district,$json_data);
                    }
                    
            	}
            	
        	}
        }
    	catch(Exception $e){ 
            $status = "<h4>".$e->getMessage()."</h4>";
            sendEmail("ERROR IN PRICEJSON_METHOD in ".$state."(".$district.")" ,$status);
        }
    }
    /*
    function innerHTML(DOMNode $node)
    {
      $doc = new DOMDocument();
      foreach ($node->childNodes as $child) {
        $doc->appendChild($doc->importNode($child, true));
      }
      return $doc->saveHTML();
    }*/
    function sendEmail($subj,$msg){
    	$to_email_address="dexterservicesmail@gmail.com";
        $fromName="Database_Error_Report";
        $subject= $subj;
        $message='<!DOCTYPE HTML>
                        <html>
                          <body style="color:Tomato;border:3px solid black;padding:10px;border-radius:10px;">'.$msg.
                             '<a href="https://www.ecowebhosting.co.uk/cp/login">Click here to modify database (or) files</a></body>
                        </html>';
        $headers = "MIME-Version: 1.0" . "\r\n"; 
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
        $headers .= 'From: '.$fromName . "\r\n";
        mail($to_email_address,$subject,$message,$headers);
      // echo "<br>Mail Sent";
    }
    
    
    //Database code end
    
    // API Code start
    // Main function to get data from API/JSON
    
    //Function to get desired Nodes from the API
    
    
?>