<?php

require __DIR__.'/vendor/autoload.php';

use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;

// This assumes that you have placed the Firebase credentials in the same directory
// as this PHP file.
$serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/marketprices-bd7be-firebase-adminsdk-zb93j-a2cf2a8bd3.json');

$firebase = (new Factory)
    ->withServiceAccount($serviceAccount)
    ->asUser('drN4k4TuESdItQ3w9gOj2Afrjxl2')
    ->create();
    
$database = $firebase->getDatabase();

$auth = $firebase->getAuth();
echo 'Firebase Connection Successful<br>';
?>