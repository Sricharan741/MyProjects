<?php
    error_reporting(true);
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    include(__DIR__."/includes/dbconfig.php");// Get firebase database
    
    $state="Telangana";
    $district="Warangal";
    $ref = 'states/Andhrapradesh/districts/Guntur/Date/details';
    echo "Data from firebase database:<br>";
    $data = $database->getReference($ref)->getSnapshot()->getValue();
    foreach($data as $key => $data1){
       echo $data1['vegname'].'<br>';
    }
?>