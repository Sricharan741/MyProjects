package com.cts.authorization;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorizatiionMicroserviceApplicationTests {

	@Test
	void main() {
		AuthorizatiionMicroserviceApplication.main(new String[] {});
	}
}
