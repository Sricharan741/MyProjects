package com.cts.mfpe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IpTreatmentOfferingApplicationTest {
	
	@Test
	void testApplicationStarts() {
		IpTreatmentOfferingApplication.main(new String[] {});
	}
	
}
