package com.cts.mfpe.exception;

@SuppressWarnings("serial")
public class PackageDetailNotFoundException extends Exception {
	public PackageDetailNotFoundException(String message) {
		super(message);
	}
}
