package com.cts.mfpe.exception;

@SuppressWarnings("serial")
public class SpecialistNotFoundException extends Exception {

	public SpecialistNotFoundException(String message) {
		super(message);
	}
}
