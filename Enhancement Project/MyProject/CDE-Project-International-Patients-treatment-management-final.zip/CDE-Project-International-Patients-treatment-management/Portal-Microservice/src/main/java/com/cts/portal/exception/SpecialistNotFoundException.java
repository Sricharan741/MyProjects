package com.cts.portal.exception;

@SuppressWarnings("serial")
public class SpecialistNotFoundException extends Exception {

	public SpecialistNotFoundException(String message) {
		super(message);
	}
}
