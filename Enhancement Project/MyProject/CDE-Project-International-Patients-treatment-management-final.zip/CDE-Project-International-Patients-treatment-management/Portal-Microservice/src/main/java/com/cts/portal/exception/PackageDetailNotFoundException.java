package com.cts.portal.exception;

@SuppressWarnings("serial")
public class PackageDetailNotFoundException extends Exception {
	public PackageDetailNotFoundException(String message) {
		super(message);
	}
}
